// ---------------------------------------------------------
//
//  scriptinit.h
//  Tyson Brochu 2011
//
//  Parse a script text file to initialize the simulation and mesh obects.
//
// ---------------------------------------------------------

#ifndef EL_TOPO_SCRIPTINIT_H
#define EL_TOPO_SCRIPTINIT_H

#include <newparser.h>
#include <surftrack.h>
#include <vec.h>
#include <vector>

class MeshDriver;

// ---------------------------------------------------------
///
/// Script parser.  Gets surface and simulation initialization parameters.
///
// ---------------------------------------------------------

class ScriptInit
{
    
public:
    
    /// Constructor
    ///
    ScriptInit() :
    output_path(),
    output_path_is_relative(false),
    frame_dt( UNINITIALIZED_DOUBLE ),
    sim_dt( UNINITIALIZED_DOUBLE ),
    end_sim_t( UNINITIALIZED_DOUBLE ),
    curr_t_specified(false),
    curr_t(0.0),
    vertices(),
    triangles(),
    masses(),
    surf_track_params(),
    driver( NULL ),
    camera_target( UNINITIALIZED_DOUBLE ),
    camera_distance( UNINITIALIZED_DOUBLE ),
    camera_heading( UNINITIALIZED_DOUBLE ),
    camera_pitch( UNINITIALIZED_DOUBLE )
    {}
    
    /// Parse the specified script
    ///
    void parse_script( const char* filename );
    
private:
    
    /// Prevent copying by not implementing
    ///
    ScriptInit( const ScriptInit& other );
    
    /// Prevent copying by not implementing
    ///
    const ScriptInit& operator=( const ScriptInit& other );
    
    /// Parse SurfTrack parameters
    ///
    void parse_surftrack_parameters( const ParseTree& surftrack_branch );

    //
    // Mesh drivers
    //
    
    /// Parse parameters for face offsetting simulation.
    ///
    void parse_faceoff( const ParseTree& faceoeff_sim_branch );   
    
    /// Parse parameters for naive motion by vertex normals.
    ///
    void parse_normal( const ParseTree& normal_sim_branch );   
    
    /// Parse parameters for motion by mean curvature.
    ///
    void parse_mean_curvature( const ParseTree& mean_curvature_sim_branch );
    
    /// Parse parameters for SISC curl noise example
    ///
    void parse_sisc_curl_noise( const ParseTree& sisc_curl_noise_sim_branch );
    
    /// Parse parameters for the Enright test.
    ///
    void parse_enright( const ParseTree& enright_sim_branch );      
    
    /// Parse camera parameters
    ///
    void parse_camera( const ParseTree& camera_branch );
    
    //
    // Geometry
    //
    
    /// Parse parameters for creating a "sheet": a rectangular open surface.
    ///
    void parse_sheet( const ParseTree& sheet_branch );
    
    /// Parse parameters for creating a "sheet": a rectangular open surface, modulated in the normal direction by a sine function.
    ///
    void parse_curved_sheet( const ParseTree& curved_sheet_branch );
    
    /// Parse parameters for creating a sphere.
    ///
    void parse_sphere( const ParseTree& sphere_branch );
    
    /// Parse parameters for creating dumbbell geometry.
    ///
    void parse_dumbbell( const ParseTree& dumbbell_branch );
    
public:
    
    //
    // Simulation settings
    //
    
    /// Output path specified in the script
    ///
    std::string output_path;
    
    /// Whether the output path is relative to the path specified by the command line
    ///
    bool output_path_is_relative;
    
    /// Length of one frame
    ///
    double frame_dt;
    
    /// Length of one simulation step
    ///
    double sim_dt;
    
    /// End of simulation time
    ///
    double end_sim_t;
    
    /// Whether the current time is specified in the script
    ///
    bool curr_t_specified;
    
    /// Current time, if specified
    ///
    double curr_t;
    
    //
    // Surface geometry
    //
    
    /// Surface vertex positions
    ///
    std::vector<Vec3d> vertices;
    
    /// Surface triangles
    ///
    std::vector<Vec3st> triangles;
    
    /// Masses of vertices
    ///
    std::vector<double> masses;
    
    /// SurfTrack parameters
    /// 
    SurfTrackInitializationParameters surf_track_params;
    
    /// MeshDriver, the simulation object
    ///
    MeshDriver* driver;
    
    /// GUI camera target
    /// 
    Vec3d camera_target;
    
    /// Z-distance from camera to target
    ///
    double camera_distance;    

    /// Camera heading (around camera y-axis) in radians
    ///
    double camera_heading;

    /// Camera pitch (around camera x-axis) in radians
    ///
    double camera_pitch;
    
};

#endif


