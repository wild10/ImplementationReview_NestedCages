// ---------------------------------------------------------
//
//  main.cpp
//  Tyson Brochu 2008
//
//  Functions for setting up and running an explicit surface simulation, 
//  as well as visualizing it with gluvi.
//
// ---------------------------------------------------------


// ---------------------------------------------------------
// Defines
// ---------------------------------------------------------

// Whether to use an OpenGL GUI, or run command-line style
// (Define NO_GUI in your build to suppress the GUI.)

//#define NO_GUI

#ifndef NO_GUI
#define USE_GUI
#endif

// Whether to run rendering and simulation on separate threads
#define RUN_ASYNC

// Whether to use the El Topo C API.  If not defined, uses the El Topo classes directly, which is faster.
//#define USE_C_API

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

// std
#include <cstdio>
#include <fenv.h>
#include <fstream>
#include <vector>
#include <queue>

// common
#include <array2.h>
#include <collisionqueries.h>
#include <expansion.h>
#include <marching_tiles_hires.h>
#include <util.h>
#include <vec.h>
#include <wallclocktime.h>

// el topo
#include <collisionpipeline.h>
#include <eltopo.h>
#include <iomesh.h>
#include <meshrenderer.h>
#include <runstats.h>
#include <surftrack.h>
#include <trianglequality.h>

// talpa
#include <framestepper.h>
#include <meancurvature.h>
#include <meshdriver.h>
#include <scriptinit.h>
#include <simulation.h>

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>

// conditional includes
#ifdef USE_GUI 
#include <gluvi.h> 
#endif


// ---------------------------------------------------------
// Global interface declarations
// ---------------------------------------------------------

int main(int argc, char **argv);

// ---------------------------------------------------------
// Global variables
// ---------------------------------------------------------

RunStats g_stats;

// ---------------------------------------------------------
// File-local variables, functions, etc.
// ---------------------------------------------------------

namespace {    
            
    SurfTrack* surf = NULL;                // The dynamic surface
    MeshDriver* driver = NULL;             // The thing that makes the dynamic surface go
    Simulation* sim = NULL;                // Timekeeping
    FrameStepper* frame_stepper = NULL;    // Useful for taking time steps when sim dt != frame dt
    
    char g_output_path[256];         // Complete path to write output data
    char g_base_output_path[256];    // Base path specified by the command line, script files can add sub-paths on top
    
    
#ifdef USE_GUI
    
    float camera_target[] = {0.0f, 0.0f, 0.0f};    // OpenGL camera points here
    Gluvi::Target3D gluvi_cam( camera_target, 10.0f, 0.0f, 0.0f, 45.0f, 0.1f, 20.0f );   // OpenGL camera
    
    MeshRenderer mesh_renderer;
    bool display_driver = false;
    const MeshDriver::MeshDriverRenderer* driver_renderer;
    Gluvi::DynamicText* status_text_widget;
        
    //
    // async stuff
    //
    
    bool advance_single_frame = false;
    bool display_status_text = true;
    
    std::vector<Vec3d> renderable_vertices;
    std::vector<Vec3d> renderable_vertex_normals;
    std::vector<Vec3st> renderable_triangles;
    std::vector<Vec2st> renderable_edges;
    
    pthread_mutex_t thread_is_running_mutex = PTHREAD_MUTEX_INITIALIZER;
    bool thread_is_running = false;
    pthread_t advance_frame_thread;
    bool waiting_for_thread_to_finish = false;
    pthread_mutex_t surf_mutex = PTHREAD_MUTEX_INITIALIZER;
    
#endif  // def USE_GUI
    
    
    // ---------------------------------------------------------
    // Interface declarations for functions local to this file
    // ---------------------------------------------------------
    
#ifdef USE_C_API
    int size_t_2_int( size_t a );
    void el_topo_wrapper_static_operations();
    void el_topo_wrapper_integrate( double dt, double& out_dt );
#endif
    
    
    void advance_sim( double dt );
    void advance_frame();
    void run_simulation( );
    void set_up_output_path( );
    
#ifdef USE_GUI
    void update_renderable_objects();
    void* advance_frame_async( void* nothing );
    void start_advance_frame();
    void advance_frame_done();
    void timer_advance_frame( int junk );
    void keyboard(unsigned char key, int x, int y);
    void mouse(int button, int state, int x, int y);
    void mouseMotion(int x, int y);
    void display(void);
    void init_gui( const ScriptInit& script_init );
#endif
    
    void init_simulation( char *script_filename );
    
    
    // ---------------------------------------------------------
    // Function definitions
    // ---------------------------------------------------------
    
#ifdef USE_C_API
    
    // ---------------------------------------------------------
    ///
    /// Wrapper for El Topo API to mesh improvement/topology change functions.
    ///
    /// This function is terribly inefficient: it copies the current state of surf to buffers, then calls the C API, which internally
    /// creates a new SurfTrack object.  This function is only included for demonstrating and testing the C API.
    ///
    // ---------------------------------------------------------
    
    void el_topo_wrapper_static_operations()
    {
        
        // Build input & options structures
        
        ElTopoMesh inputs;
        inputs.num_vertices = size_t_2_int( surf->get_num_vertices() );
        inputs.vertex_locations = new double[ 3*inputs.num_vertices ];
        memcpy( inputs.vertex_locations, &(surf->get_position(0)), 3*inputs.num_vertices*sizeof(double) );   
        
        inputs.num_triangles = size_t_2_int( surf->m_mesh.num_triangles() );
        inputs.triangles = new int[ 3*inputs.num_triangles ];
        for ( int i = 0; i < inputs.num_triangles; ++i )
        {
            inputs.triangles[3*i+0] = size_t_2_int( surf->m_mesh.get_triangle(i)[0] );
            inputs.triangles[3*i+1] = size_t_2_int( surf->m_mesh.get_triangle(i)[1] );
            inputs.triangles[3*i+2] = size_t_2_int( surf->m_mesh.get_triangle(i)[2] );
        }
        
        inputs.vertex_masses = new double[ inputs.num_vertices ];
        memcpy( inputs.vertex_masses, &(surf->m_masses[0]), inputs.num_vertices*sizeof(double) );
        
        ElTopoGeneralOptions general_options;
        general_options.m_verbose = surf->m_verbose;
        general_options.m_collision_safety = surf->m_collision_safety;
        general_options.m_proximity_epsilon = surf->m_proximity_epsilon;
        
        ElTopoStaticOperationsOptions options;
        options.m_perform_improvement = surf->m_perform_improvement;
        options.m_allow_topology_changes = surf->m_allow_topology_changes;
        options.m_max_volume_change = surf->m_max_volume_change;
        options.m_min_edge_length = surf->m_min_edge_length;
        options.m_max_edge_length = surf->m_max_edge_length;
        options.m_min_triangle_area = surf->m_min_triangle_area;
        options.m_min_triangle_angle = surf->m_min_triangle_angle;
        options.m_max_triangle_angle = surf->m_max_triangle_angle;
        options.m_use_curvature_when_splitting = surf->m_splitter.m_use_curvature;
        options.m_use_curvature_when_collapsing = surf->m_collapser.m_use_curvature;
        options.m_min_curvature_multiplier = surf->m_collapser.m_min_curvature_multiplier;
        options.m_max_curvature_multiplier = surf->m_splitter.m_max_curvature_multiplier;
        options.m_allow_vertex_movement = surf->m_allow_vertex_movement;
        options.m_edge_flip_min_length_change = surf->m_edge_flip_min_length_change;
        options.m_merge_proximity_epsilon = surf->m_merge_proximity_epsilon;
        options.m_subdivision_scheme = surf->m_subdivision_scheme;
        
        ElTopoMesh outputs;
        ElTopoDefragInformation defrag_info;
        
        el_topo_static_operations( &inputs, &general_options, &options, &defrag_info, &outputs );
        
        {
            surf->improve_mesh();
            surf->topology_changes();
            surf->defrag_mesh();
            
            assert( size_t_2_int( surf->m_mesh.num_triangles() ) == outputs.num_triangles );
            assert( size_t_2_int( surf->get_num_vertices() ) == outputs.num_vertices );      
        }
        
        
        //
        // Update surface info
        //
        
        surf->set_all_positions( outputs.num_vertices, outputs.vertex_locations );
        
        surf->m_masses.resize( outputs.num_vertices );
        for( int i = 0; i < outputs.num_vertices; ++i )
        {
            surf->m_masses[i] = outputs.vertex_masses[i];
        }
        
        std::vector<Vec3st> new_triangles( outputs.num_triangles );
        for ( size_t i = 0; i < new_triangles.size(); ++i )
        {
            new_triangles[i][0] = outputs.triangles[3*i+0];
            new_triangles[i][1] = outputs.triangles[3*i+1];
            new_triangles[i][2] = outputs.triangles[3*i+2];      
        }
        
        surf->m_mesh.replace_all_triangles( new_triangles );
        
        //
        // Send change history to mesh driver
        //
        
        surf->m_vertex_change_history.resize( defrag_info.num_vertex_changes );
        
        for ( int i = 0; i < defrag_info.num_vertex_changes; ++i )
        {
            surf->m_vertex_change_history[i].is_remove = defrag_info.vertex_is_remove[i];
            surf->m_vertex_change_history[i].vertex_index = defrag_info.vertex_index[i];
            surf->m_vertex_change_history[i].split_edge[0] = defrag_info.split_edge[2*i+0];
            surf->m_vertex_change_history[i].split_edge[1] = defrag_info.split_edge[2*i+1];
        }
        
        surf->m_triangle_change_history.resize( defrag_info.num_triangle_changes );
        
        for ( int i = 0; i < defrag_info.num_triangle_changes; ++i )
        {
            surf->m_triangle_change_history[i].is_remove = defrag_info.triangle_is_remove[i];
            surf->m_triangle_change_history[i].triangle_index = defrag_info.triangle_index[i];
            surf->m_triangle_change_history[i].tri[0] = defrag_info.new_tri[3*i+0];
            surf->m_triangle_change_history[i].tri[1] = defrag_info.new_tri[3*i+1];
            surf->m_triangle_change_history[i].tri[2] = defrag_info.new_tri[3*i+2];
        }
        
        surf->m_defragged_triangle_map.resize( defrag_info.defragged_triangle_map_size );
        
        for ( int i = 0; i < defrag_info.defragged_triangle_map_size; ++i )
        {
            surf->m_defragged_triangle_map[i][0] = defrag_info.defragged_triangle_map[2*i+0];
            surf->m_defragged_triangle_map[i][1] = defrag_info.defragged_triangle_map[2*i+1];
        }
        
        surf->m_defragged_vertex_map.resize( defrag_info.defragged_vertex_map_size );
        
        for ( int i = 0; i < defrag_info.defragged_vertex_map_size; ++i )
        {
            surf->m_defragged_vertex_map[i][0] = defrag_info.defragged_vertex_map[2*i+0];
            surf->m_defragged_vertex_map[i][1] = defrag_info.defragged_vertex_map[2*i+1];
        }
        
        driver->update_simulation_elements( *surf );
        
        
        // Free allocated memory
        
        delete[] inputs.triangles;
        delete[] inputs.vertex_locations;
        delete[] inputs.vertex_masses;
        
        el_topo_free_static_operations_results( &outputs, &defrag_info );
        
    }
    
    // ---------------------------------------------------------
    ///
    /// Wrapper for El Topo API to mesh integration/collision detection.
    ///
    /// This function is terribly inefficient: it copies the current state of surf to buffers, then calls the C API, which internally
    /// creates a new SurfTrack object.  This function is only included for demonstrating and testing the C API.
    ///
    // ---------------------------------------------------------
    
    void el_topo_wrapper_integrate( double dt, double& out_dt )
    {
        
        ElTopoMesh inputs;
        inputs.num_vertices = size_t_2_int( surf->get_num_vertices() );
        inputs.vertex_locations = new double[ 3*inputs.num_vertices ];
        memcpy( inputs.vertex_locations, &(surf->get_position(0)), 3*inputs.num_vertices*sizeof(double) );   
        
        inputs.num_triangles = size_t_2_int( surf->m_mesh.num_triangles() );
        inputs.triangles = new int[ 3*inputs.num_triangles ];
        
        for ( int i = 0; i < inputs.num_triangles; ++i )
        {
            const Vec3st& tri = surf->m_mesh.get_triangle(i);
            inputs.triangles[3*i+0] = size_t_2_int( tri[0] );
            inputs.triangles[3*i+1] = size_t_2_int( tri[1] );
            inputs.triangles[3*i+2] = size_t_2_int( tri[2] );
        }
        
        inputs.vertex_masses = new double[ inputs.num_vertices ];
        memcpy( inputs.vertex_masses, &(surf->m_masses[0]), inputs.num_vertices*sizeof(double) );
        
        assert( size_t_2_int( surf->m_masses.size() ) == inputs.num_vertices );
        for ( int i = 0; i < inputs.num_vertices; ++i )
        {
            assert( surf->m_masses[i] == surf->m_masses[i] );
            assert( surf->m_masses[i] != 0.0 );
            assert( inputs.vertex_masses[i] == inputs.vertex_masses[i] );
            assert( inputs.vertex_masses[i] != 0.0  );
        }
        
        ElTopoGeneralOptions general_options;
        general_options.m_verbose = surf->m_verbose;
        general_options.m_collision_safety = surf->m_collision_safety;
        general_options.m_proximity_epsilon = surf->m_proximity_epsilon;
        
        ElTopoIntegrationOptions options;
        options.m_dt = dt;
        options.m_friction_coefficient = surf->m_collision_pipeline->m_friction_coefficient;
        
        double* new_vertex_locations = new double[ 3 * surf->get_num_vertices() ];
        
        memcpy( new_vertex_locations, &(surf->get_newposition(0)), 3 * surf->get_num_vertices() * sizeof(double) );
        
        double* out_vertex_locations;
        
        el_topo_integrate( &inputs, new_vertex_locations, &general_options, &options, &out_vertex_locations, &out_dt );
        
        surf->set_all_positions( surf->get_num_vertices(), out_vertex_locations );
        surf->set_all_newpositions( surf->get_num_vertices(), out_vertex_locations );
        
        delete[] inputs.triangles;
        delete[] inputs.vertex_locations;
        delete[] inputs.vertex_masses;
        
        delete[] new_vertex_locations;
        
        el_topo_free_integrate_results( out_vertex_locations );
        
        
    }
    
#endif   // USE_C_API
    
    
    // ---------------------------------------------------------
    ///
    /// Advance simulation, GUI-ignorant
    ///
    // ---------------------------------------------------------
    
    void advance_sim( double sim_dt )
    {
        
        double start_time = get_time_in_seconds();
        
        double accum_dt = 0;
        
        while ( (accum_dt < 0.99 * sim_dt) && (sim->m_curr_t + accum_dt < sim->m_max_t) )
        {       
            
            std::cout << "\n\n ------- sim step ------- \n\n";
            
            std::cout << "curr t: " << sim->m_curr_t + accum_dt << " / " << sim->m_max_t << std::endl;
            
            // ----------
            // collect stats
            // ----------
            
            g_stats.add_to_int( "total_sim_steps", 1 );
            g_stats.update_min_int( "min_num_triangles", (int) surf->m_mesh.num_triangles() ); 
            g_stats.update_max_int( "max_num_triangles", (int) surf->m_mesh.num_triangles() );
            g_stats.add_to_int( "total_num_vertices", surf->get_num_vertices() );
            g_stats.update_min_int( "min_num_vertices", (int) surf->get_num_vertices() );
            g_stats.update_max_int( "max_num_vertices", (int) surf->get_num_vertices() );
            g_stats.add_to_int( "total_num_triangles", surf->m_mesh.num_triangles() );
            
            // ---------- 
            // mesh maintenance & topology changes
            // ---------- 
            
            
#ifdef USE_C_API
            el_topo_wrapper_static_operations();
#else
            {         
                // Improve
                
                double pre_improve_time = get_time_in_seconds();
                surf->improve_mesh();
                double post_improve_time = get_time_in_seconds();
                g_stats.add_to_double( "total_improve_time", post_improve_time - pre_improve_time );
                
                // Topology changes
                
                double pre_topology_time = get_time_in_seconds();
                surf->topology_changes();
                double post_topology_time = get_time_in_seconds();
                g_stats.add_to_double( "total_topology_time", post_topology_time - pre_topology_time );
                
                surf->defrag_mesh();
                
                // Update driver
                
                driver->update_simulation_elements( *surf );
                
            }
#endif
            
            
            double min_angle = min_triangle_angle( *surf );   
            g_stats.add_per_frame_double( "min_angle", frame_stepper->get_frame(), rad2deg(min_angle) );
            double max_angle = max_triangle_angle( *surf );
            g_stats.add_per_frame_double( "max_angle", frame_stepper->get_frame(), rad2deg(max_angle) );
            
            char imp_stats_filename[256];
            sprintf( imp_stats_filename, "%s/aaa-imp-stats.txt", g_output_path );      
            g_stats.write_to_file( imp_stats_filename );
            
            // ---------- 
            // advance underlying simulation
            // ----------
            
            double curr_dt = sim_dt - accum_dt;
            curr_dt = min( curr_dt, sim->m_max_t - sim->m_curr_t - accum_dt );
            
            std::cout << "curr_dt: " << curr_dt << std::endl;
            
            double time_before_driver = get_time_in_seconds();
            
            std::vector<Vec3d> new_positions( surf->get_num_vertices() );
            driver->set_predicted_vertex_positions( *surf, new_positions, sim->m_curr_t + accum_dt, curr_dt );
            
            surf->set_all_newpositions( new_positions );
            
            std::cout << "sim_dt: " << curr_dt << std::endl;
            
            double time_after_driver = get_time_in_seconds();
            g_stats.add_to_double( "total_driver_time", time_after_driver - time_before_driver );
            
            // ----------
            // move & handle collision detection
            // ----------
            
            double time_before_integration = get_time_in_seconds();             
            double actual_dt;
            
            std::vector<Vec3d> initial_positions = surf->get_positions();
            
#ifdef USE_C_API
            el_topo_wrapper_integrate( curr_dt, actual_dt );
#else
            surf->integrate( curr_dt, actual_dt );
#endif
            
            curr_dt = actual_dt;    // the time step actually taken by el topo
            
            std::cout << "actual_dt: " << actual_dt << std::endl;
            
            std::vector<Vec3d> final_positions = surf->get_positions();
            
            double curr_integration_time = get_time_in_seconds() - time_before_integration;
            g_stats.add_to_double( "total_integration_time", curr_integration_time );
            
            accum_dt += curr_dt;
            
            //
            // Need to inform the driver what the actual vertex motion was (e.g. for velocity update)
            //
            
            driver->notify_done_integration( initial_positions, final_positions, actual_dt );
            
            driver->compute_error( *surf, sim->m_curr_t + accum_dt );
            
            
            //
            // file output
            //
            
            char binary_filename[256];
            sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, frame_stepper->get_frame() );      
            write_binary_file( surf->m_mesh, surf->get_positions(), surf->m_masses, sim->m_curr_t, binary_filename );   
            
            char stats_filename[256];
            sprintf( stats_filename, "%s/aaa-stats.txt", g_output_path );      
            g_stats.write_to_file( stats_filename );
            
        }
        
        std::cout << " -------------- end sim step -------------- \n" << std::endl;
        
        double sim_step_time = get_time_in_seconds() - start_time;
        g_stats.add_to_double( "total_sim_time", sim_step_time );
        
        sim->m_curr_t += accum_dt;
        
        g_stats.add_per_frame_int( "num_vertices", frame_stepper->get_frame(), surf->get_num_vertices() );
        g_stats.add_per_frame_int( "num_triangles", frame_stepper->get_frame(), surf->m_mesh.num_triangles() );
        
        // ----------
        // check if max time is reached
        // ----------
        
        if ( sim->done_simulation() )
        {         
            sim->m_running = false;
            std::cout << "total time steps: " << g_stats.get_int( "total_sim_steps" ) << std::endl;
        }
        
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Advance simulation by one frame
    ///
    // ---------------------------------------------------------
    
    void advance_frame()
    {
        
        if( !sim->m_currently_advancing_simulation )
        {
            sim->m_currently_advancing_simulation = true;
            
            //
            // Advance frame
            //
            
            std::cout << "\n --------------- frame " << frame_stepper->get_frame() << " --------------- \n" << std::endl;
            
            while ( !(frame_stepper->done_frame()) )
            {
                double dt = frame_stepper->get_step_length( sim->m_dt );
                advance_sim( dt );
                frame_stepper->advance_step( dt );         
            }
            
            std::cout << " --------------- end frame " << frame_stepper->get_frame() << " --------------- \n" << std::endl;
            
            // update frame stepper      
            frame_stepper->next_frame();
            
            sim->m_currently_advancing_simulation = false;
            
        }
        
    }
    
    
    
    // ---------------------------------------------------------
    ///
    /// Run an entire simulation without GUI.  No threading.
    ///
    // ---------------------------------------------------------
    void run_simulation( )
    {
        sim->m_running = true;
        while ( sim->m_running )
        {
            advance_frame();
        }
        sim->m_running = false;
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Run all examples from the SISC submission
    ///
    // ---------------------------------------------------------
    
    void run_all_sisc_examples( const char* sisc_script_directory )
    {
        std::cout << "\n\n\n -------------- running all SISC examples -------------- \n\n\n" << std::endl;
        
        std::vector<std::string> sisc_script_filenames;
        sisc_script_filenames.push_back( "faceoff-params-1.txt" );
        sisc_script_filenames.push_back( "faceoff-params-2.txt" );
        sisc_script_filenames.push_back( "faceoff-params-3.txt" );         
        sisc_script_filenames.push_back( "normal-params-1.txt" );
        sisc_script_filenames.push_back( "normal-params-2.txt" );
        sisc_script_filenames.push_back( "normal-params-3.txt" );      
        sisc_script_filenames.push_back( "mc-params-1.txt" );   
        sisc_script_filenames.push_back( "mc-params-2.txt" );   
        sisc_script_filenames.push_back( "mc-params-3.txt" );         
        sisc_script_filenames.push_back( "enright-parameters.txt" );
        sisc_script_filenames.push_back( "open-curlnoise-parameters.txt" );
        sisc_script_filenames.push_back( "curlnoise-parameters.txt" );
        sisc_script_filenames.push_back( "tangled.txt" );
        
        for ( unsigned int i = 0; i < sisc_script_filenames.size(); ++i )
        {
            delete sim;
            delete surf;
            delete driver;
            
            // re-initialize the simulation
            char filename[256];
            strcpy( filename, sisc_script_directory );
            strcat( filename, sisc_script_filenames[i].c_str() );
            
            init_simulation( filename );
            
            g_stats.clear();
            
            std::cout << "\n\n\n ---------------------------- " << std::endl;
            std::cout << "output path: " << g_output_path << std::endl;
            
            char mkdir_command[1024];
            sprintf( mkdir_command, "mkdir -p %s", g_output_path );
            system(mkdir_command);
            
            run_simulation();
            
            std::cout << "\n -------------- sim done -------------- \n\n\n" << std::endl;
            
        }
        
    }
    
    
#ifdef USE_GUI
    
    // ---------------------------------------------------------
    ///
    /// Copy the mesh objects from the simulation object to renderable object.
    ///
    // ---------------------------------------------------------
    
    void update_renderable_objects()
    {
        // aquire mutex on surf object
        pthread_mutex_lock( &surf_mutex );   
        
        renderable_vertices = surf->get_positions();
        renderable_triangles = surf->m_mesh.get_triangles();
        renderable_edges = surf->m_mesh.m_edges;
        
        // compute vertex normals
        surf->get_all_vertex_normals( renderable_vertex_normals );
        
        // get cached driver visualizer
        driver_renderer = driver->get_renderer();
        
        
        // release mutex
        int ok = pthread_mutex_unlock( &surf_mutex );
        assert( ok == 0 );
    }
    
    // ---------------------------------------------------------
    ///
    /// Advance simulation by one frame.  Runs on a separate thread.
    ///
    // ---------------------------------------------------------
    
    void* advance_frame_async( void* )
    {      
        // advance one frame
        pthread_mutex_lock( &surf_mutex );
        advance_frame();   
        int ok = pthread_mutex_unlock( &surf_mutex );   
        assert( ok == 0 );
        
        // and signal we're done
        pthread_mutex_lock( &thread_is_running_mutex );
        thread_is_running = false;
        ok = pthread_mutex_unlock( &thread_is_running_mutex );
        assert( ok == 0 );
        
        return NULL;
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Launch a thread to advance the simulation.
    ///
    // ---------------------------------------------------------
    
    void start_advance_frame()
    {
        
        // make sure no frame is currently running
        
        pthread_mutex_lock( &thread_is_running_mutex );
        
        if ( !thread_is_running && !waiting_for_thread_to_finish )
        {
            thread_is_running = true;
            
            int ok = pthread_mutex_unlock( &thread_is_running_mutex );
            assert( ok == 0 );
            
            // If first frame, output initial screen cap
            
            if ( frame_stepper->get_frame() == 0 )
            {
                // output initial conditions
                char sgi_filename[256];
                sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, frame_stepper->get_frame() );      
                Gluvi::sgi_screenshot( sgi_filename );         
            }
            
            waiting_for_thread_to_finish = true;
            
#ifdef RUN_ASYNC
            // kick off advance_frame_async  
            pthread_create( &advance_frame_thread, NULL, advance_frame_async, NULL );
#else
            advance_frame_async( 0 );
#endif
            
            pthread_mutex_lock( &thread_is_running_mutex );
            
        }
        
        int ok = pthread_mutex_unlock( &thread_is_running_mutex );
        assert( ok == 0 );
        
    }
    
    // ---------------------------------------------------------
    ///
    /// Called when a simulation thread returns after advancing one frame in sim time.
    ///
    // ---------------------------------------------------------
    
    void advance_frame_done()
    {
        // copy sim data into render buffers
        update_renderable_objects();
        
        pthread_mutex_lock( &surf_mutex );
        
        char sgi_filename[256];
        sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, frame_stepper->get_frame() );      
        Gluvi::sgi_screenshot( sgi_filename );
        
        // allow the driver to write to disk (e.g. for caching simulation data)
        driver->write_to_disk( g_output_path, frame_stepper->get_frame() );
        
        int ok = pthread_mutex_unlock( &surf_mutex );
        assert( ok == 0 );
        
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Callback on the OpenGL timer to keep advancing the simulation.
    ///
    // ---------------------------------------------------------
    
    void timer_advance_frame( int )
    {
        
        if ( sim->m_running || advance_single_frame )
        {
            start_advance_frame();
            advance_single_frame = false;
        }
        
        glutPostRedisplay();
        
    }
    
    // ---------------------------------------------------------
    ///
    /// Handle keyboard input
    ///
    // ---------------------------------------------------------
    
    void keyboard(unsigned char key, int, int )
    {
        
        if(key == 'q')
        {
            pthread_mutex_lock( &surf_mutex );   
            delete surf;
            pthread_mutex_unlock( &surf_mutex );   
            delete driver;
            exit(0);
        }
        
        if ( key == 's' )
        {
            display_driver = !display_driver;
        }
        
        // run one frame
        // 
        if(key == 'n')
        {
            advance_single_frame = true;
        }
        
        if ( key == 'e' )
        {
            mesh_renderer.render_edges = !mesh_renderer.render_edges;
        }
        
        if ( key == 't' )
        {
            mesh_renderer.render_fill_triangles = !mesh_renderer.render_fill_triangles;
        }
        
        if ( key == 'v' )
        {
            mesh_renderer.render_vertex_rank = !mesh_renderer.render_vertex_rank;
        }
        
        
        // return to default camera
        //
        if ( key == 'r' )
        {
            gluvi_cam.return_to_default();
        }
        
        // define default camera
        //
        if ( key == 'd' )
        {
            gluvi_cam.default_target[0] = gluvi_cam.target[0];
            gluvi_cam.default_target[1] = gluvi_cam.target[1];
            gluvi_cam.default_target[2] = gluvi_cam.target[2];      
            gluvi_cam.default_dist = gluvi_cam.dist;
            gluvi_cam.default_heading = gluvi_cam.heading;
            gluvi_cam.default_pitch = gluvi_cam.pitch;   
            
            std::cout << "cam_target " << gluvi_cam.default_target[0] << " " <<  gluvi_cam.default_target[1] << " " << gluvi_cam.default_target[2] << std::endl;
            std::cout << "cam_distance " << gluvi_cam.default_dist << std::endl;
            std::cout << "cam_heading " << gluvi_cam.default_heading << std::endl;
            std::cout << "cam_pitch " << gluvi_cam.default_pitch << std::endl;
        }
        
        // output binary file
        //
        if(key == 'b')
        {
            pthread_mutex_lock( &surf_mutex );   
            char binary_filename[256];
            sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, frame_stepper->get_frame() );      
            write_binary_file( surf->m_mesh, surf->get_positions(), surf->m_masses, sim->m_curr_t, binary_filename );   
            std::cout << "binary file written" << std::endl;      
            pthread_mutex_unlock( &surf_mutex );   
        }
        
        // SGI screenshot
        //
        if(key == 'p')
        {
            pthread_mutex_lock( &surf_mutex );   
            char sgi_filename[256];
            sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, frame_stepper->get_frame() );      
            Gluvi::sgi_screenshot( sgi_filename );
            std::cout << "sgi screen shot taken" << std::endl;
            pthread_mutex_unlock( &surf_mutex );   
        }
        
        // toggle simulation running
        //
        if(key == ' ')
        {
            advance_single_frame = false;
            sim->m_running = !sim->m_running;
            std::cout << "running: " << (sim->m_running ? "yes" : "no") << std::endl;
        }
        
        if ( key == 'Z' )
        {
            run_all_sisc_examples( "./sisc-scripts/" );
        }
        
        timer_advance_frame(0);
        
        glutPostRedisplay();
        
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Handle mouse click
    ///
    // ---------------------------------------------------------
    
    void mouse(int button, int state, int x, int y)
    {
        gluvi_cam.click(button, state, x, y);
    }
    
    // ---------------------------------------------------------
    ///
    /// Handle mouse motion
    ///
    // ---------------------------------------------------------
    
    void mouseMotion(int x, int y)
    {
        gluvi_cam.drag(x, y);
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Render to the OpenGL GUI.  Rendering the triangle surface is handled by SurfTrack::render
    ///
    // ---------------------------------------------------------
    
    void display(void)
    {
        
        if ( ! Gluvi::taking_screenshot )
        {
            
            if ( display_status_text )
            {
                pthread_mutex_lock( &thread_is_running_mutex );
                if ( thread_is_running )
                {
                    if ( sim->m_running )
                    {
                        // running async
                        status_text_widget->set_color( 0.0f, 0.0f, 0.0f );
                        status_text_widget->text = "Running --- path:" + std::string( g_output_path );
                    }
                    else
                    {
                        // stopping after the current frame
                        status_text_widget->set_color( 0.8f, 0.2f, 0.2f );         
                        status_text_widget->text = "Stopping...";
                    }
                }
                else
                {
                    if ( waiting_for_thread_to_finish )
                    {
                        
                        // thread has signalled that it's done
                        // wait for the thread to finish and be destroyed
                        pthread_join( advance_frame_thread, NULL );
                        
                        waiting_for_thread_to_finish = false;
                        
                        advance_frame_done();
                        
                        status_text_widget->set_color( 0.0f, 0.0f, 0.0f );
                        status_text_widget->text = "Ready";
                        
                    }
                }
                int ok = pthread_mutex_unlock( &thread_is_running_mutex );
                assert( ok == 0 );
            }
            else
            {
                status_text_widget->set_color( 1.0f, 1.0f, 1.0f );
                status_text_widget->text = "";
            }
            
            // now should immediately check if we should launch another thread
            
            timer_advance_frame(0);
            
        }
        
        
        //
        // Render the mesh
        //
        
        mesh_renderer.render( renderable_vertices, 
                             renderable_vertex_normals,
                             renderable_triangles,
                             renderable_edges );
        
        //
        // Render the simulation
        //
        
        if ( display_driver && driver_renderer != NULL )
        {
            driver_renderer->render();
        }
        
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Initialize the OpenGL GUI
    ///
    // ---------------------------------------------------------
    
    void init_gui( const ScriptInit& script_init )
    {
        
        glClearColor(1,1,1,0);
        Gluvi::camera = &gluvi_cam;
        
        gluvi_cam.target[0] = static_cast<float>(script_init.camera_target[0]);
        gluvi_cam.target[1] = static_cast<float>(script_init.camera_target[1]);
        gluvi_cam.target[2] = static_cast<float>(script_init.camera_target[2]);   
        gluvi_cam.dist = static_cast<float>(script_init.camera_distance);
        gluvi_cam.heading = static_cast<float>(script_init.camera_heading);
        gluvi_cam.pitch = static_cast<float>(script_init.camera_pitch);
        
        // set to default
        gluvi_cam.default_target[0] = gluvi_cam.target[0];
        gluvi_cam.default_target[1] = gluvi_cam.target[1];
        gluvi_cam.default_target[2] = gluvi_cam.target[2];      
        gluvi_cam.default_dist = gluvi_cam.dist;
        gluvi_cam.default_heading = gluvi_cam.heading;
        gluvi_cam.default_pitch = gluvi_cam.pitch;   
        
        
        Gluvi::userDisplayFunc=display;
        
        glutKeyboardFunc(keyboard);
        glutMouseFunc(mouse);
        glutMotionFunc(mouseMotion);
        
        status_text_widget = new Gluvi::DynamicText( "Ready" );
        Gluvi::root.list.push_back( status_text_widget );
        
        gluvi_cam.gl_transform();
        
        update_renderable_objects();
    }
    
#endif  // #ifdef USE_GUI
    
    
    // ---------------------------------------------------------
    ///
    /// Set the output directory. Assigns to the next "run#" in the user-specified output directory.
    ///
    // ---------------------------------------------------------
    
    void set_up_output_path( )
    {
        
        DIR *dp;
        struct dirent *ep;     
        dp = opendir ( g_output_path );
        
        int max_dir = 0;
        
        if (dp != NULL)
        {      
            while ( (ep = readdir (dp)) != 0 )
            {
                
                std::string name_string( ep->d_name );
                
                //if ( ep->d_type == DT_DIR )    // doesn't exist on all platforms
                {
                    int i;
                    int num_variables_read = sscanf (name_string.c_str(), "run%04d", &i );
                    if ( num_variables_read > 0 )
                    {
                        max_dir = max( max_dir, i );
                    }
                }
            }
            
            (void) closedir (dp);
        }
        else
        {
            std::cout << "Couldn't open the directory" << std::endl;
        }
        
        sprintf( g_output_path, "%s/run%04d", g_output_path, max_dir + 1 );
        std::cout << "g_output_path: " << g_output_path << std::endl;
        
        char mkdir_command[1024];
        sprintf( mkdir_command, "mkdir -p %s", g_output_path );
        system(mkdir_command);
        
    }
    
    
    // ---------------------------------------------------------
    ///
    /// Initialize the simulation.  Set the simulation parameters, initial geometry, etc.
    ///
    // ---------------------------------------------------------
    
    void init_simulation( char *script_filename )
    {
        
        SurfTrackInitializationParameters init_params;
        
        std::vector<Vec3ui> tris;
        std::vector<Vec3d> verts;
        std::vector<Vec3d> velocities;
        std::vector<double> masses;
        
        ScriptInit script_init;
        script_init.parse_script( script_filename );
        
        if ( script_init.output_path_is_relative )
        {
            snprintf( g_output_path, 256, "%s/%s", g_base_output_path, script_init.output_path.c_str() );
        }
        else
        {
            snprintf( g_output_path, 256, "%s", script_init.output_path.c_str() );
        }
        
        // Init frame stepper
        
        frame_stepper = new FrameStepper( script_init.frame_dt );
        
        // init simulation
        
        if ( script_init.end_sim_t != UNINITIALIZED_DOUBLE )
        {
            sim = new Simulation( script_init.sim_dt, script_init.end_sim_t );
        }
        else
        {
            sim = new Simulation( script_init.sim_dt );
        }
        
        if ( script_init.curr_t_specified )
        {
            sim->m_curr_t = script_init.curr_t;
            
            unsigned int curr_frame = static_cast<unsigned int>(script_init.curr_t / script_init.frame_dt); 
            std::cout << "curr_t: " << sim->m_curr_t << std::endl;
            std::cout << "curr_frame: " << curr_frame << std::endl; 
            
            frame_stepper->frame_count = curr_frame;
        }
        
        
        // init SurfTrack
        
        surf = new SurfTrack( script_init.vertices, script_init.triangles, script_init.masses, script_init.surf_track_params );   
        
        surf->defrag_mesh();
        surf->m_defragged_triangle_map.clear();
        surf->m_defragged_vertex_map.clear();
        
        // init driver
        
        driver = script_init.driver;   
        driver->initialize( *surf );
        
        if ( surf->m_collision_safety )
        {
            surf->assert_mesh_is_intersection_free( false );      
        }
        
        g_stats.set_double( "max_edge_length", surf->m_splitter.m_max_edge_length );
        g_stats.set_double( "min_edge_length", surf->m_collapser.m_min_edge_length );
        g_stats.set_double( "max_volume_change", surf->m_max_volume_change );
        
        set_time_base();
        
#ifdef USE_GUI
        
        init_gui( script_init );
        
#endif
        
        
    }
    
}  // unnamed namespace


// ---------------------------------------------------------
///
/// MAIN
///
// ---------------------------------------------------------

int main(int argc, char **argv)
{   
    
    std::cout << "Talpa: Demo applications of El Topo" << std::endl;
    std::cout << "-----------------------------------" << std::endl << std::endl;
    
    if( argc < 2 )
    {
        std::cout << "Usage: <executable> <scriptfile> <outputbasedirectory>" << std::endl;
        std::cout << "e.g.: " << std::endl;
        std::cout << "$ ./talpa_release curlnoise-parameters.txt /var/tmp/" << std::endl;
        return 0;
    }
    
    // set path for outputting obj, bin files, etc.
    
    if ( argc > 2 )
    {
        strcpy( g_base_output_path, argv[2] );
    }
    else
    {
        // argc == 2
        strcpy( g_base_output_path, "./" );
    }
    
#ifdef USE_GUI
    pthread_mutexattr_t mta;
    int rc = pthread_mutexattr_init(&mta);
    rc = pthread_mutexattr_settype(&mta, PTHREAD_MUTEX_ERRORCHECK );
    rc = pthread_mutex_init(&thread_is_running_mutex, &mta);
    
    Gluvi::winwidth = 800;
    Gluvi::winheight = 600;
    
    Gluvi::init( "Talpa", &argc, argv );
#endif
    
    //
    // Initialize the simulation using the script file
    //
    
    init_simulation( argv[1] );
    
    
    //
    // Make a new directory for output
    //
    
    set_up_output_path();
    
    //
    // Make a copy of the input script in the output directory
    //
    
    char* script_filename = argv[1];
    std::ifstream original_file_stream( script_filename );
    assert( original_file_stream.good() );
    
    char script_copy_filename[256];
    snprintf( script_copy_filename, 256, "%s/aaa-script.txt", g_output_path );
    
    char command[1024];
    sprintf( command, "cp %s %s", script_filename, script_copy_filename );
    system(command);
    
    srand( 1 );
    
    // write frame 0
    char binary_filename[256];
    sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, frame_stepper->get_frame() );      
    write_binary_file( surf->m_mesh, surf->get_positions(), surf->m_masses, sim->m_curr_t, binary_filename );   
    
    driver->write_to_disk( g_output_path, frame_stepper->get_frame() );
    
    //
    // Now start
    //
    
#ifdef USE_GUI
    // start the GUI
    Gluvi::run();
#else
    
    // start the simulation (hands off)
    run_simulation();
    
    // uncomment to run all examples in our SISC paper:
    //run_all_sisc_examples( "./sisc-scripts/" );
    
#endif
    
    return 0;
}



