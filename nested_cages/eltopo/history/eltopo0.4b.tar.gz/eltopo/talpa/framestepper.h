// ---------------------------------------------------------
//
//  framestepper.h
//  Tyson Brochu 2011
//  
//  Control frame sub-steps when the sim dt is not equal to the frame dt.
//
// ---------------------------------------------------------


#ifndef EL_TOPO_FRAMESTEPPER_H
#define EL_TOPO_FRAMESTEPPER_H

// ---------------------------------------------------------
///
/// An object for handling sim time stepping when the sim rate is not equal to the frame rate.
///
// ---------------------------------------------------------

class FrameStepper 
{
    
public:
    
    /// Constructor
    ///
    FrameStepper ( double frame_len ) :
    frame_length(frame_len),
    frame_count(0),
    current_time(0), 
    step_count(0)
    {}
    
    /// adjust the timestep to land on a frame time, or to use more evenly spaced steps if close to a frame time
    ///
    double get_step_length(double max_step)
    {
        if(current_time + max_step > frame_length)
            max_step = frame_length - current_time;
        return max_step;     
    }
    
    /// Determine if the frame is done.  We're done when current time is very close or past the frame_length.
    ///
    bool done_frame()
    {
        return current_time >= frame_length - 1e-7;
    }
    
    /// Advance the current time by the specified step size
    ///
    void advance_step(double step_length)
    {
        current_time += step_length;
        ++step_count;
    }
    
    /// Increment the frame count, and reset the current accumulated time
    ///
    void next_frame()
    {
        current_time = 0;
        step_count = 0;
        ++frame_count;
    }   
    
    /// Return the number of steps taken within this frame
    ///
    int get_step_count()
    {
        return step_count;
    }
    
    /// Return the number of frames already passed
    ///
    int get_frame()
    {
        return frame_count;
    }
    
    /// Get the current global sim time
    ///
    double get_time()
    {
        return (frame_count-1)*frame_length + current_time;
    }
    
    /// length of a frame in seconds
    ///
    double frame_length;            
    
    /// always the frame currently being processed
    ///
    int frame_count;              
    
    /// current time within a frame
    ///
    double current_time;          
    
    /// current step within the frame
    ///
    int step_count;               

    
};


#endif

