// ---------------------------------------------------------
//
//  meshdriver.h
//  Tyson Brochu 2008
//
//  Interface for a class that specifies vertex velocities over a mesh.
//
// ---------------------------------------------------------

#ifndef EL_TOPO_MESHDRIVER_H
#define EL_TOPO_MESHDRIVER_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <surftrack.h>
#include <vec.h>
#include <vector>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Class definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Base class for anything that moves a dynamic mesh
///
// ---------------------------------------------------------

class MeshDriver
{
public:
    
    // ---------------------------------------------------------
    ///
    /// Rendering object
    ///
    // ---------------------------------------------------------
    
    class MeshDriverRenderer
    {
    public:
        virtual ~MeshDriverRenderer() {}
        virtual void render() const {}
    };
    
    /// Get the driver rendering object for this MeshDriver object
    ///
    virtual const MeshDriverRenderer* get_renderer()
    {
        return NULL;
    }
    
    /// Destructor
    ///
    virtual ~MeshDriver() {}
    
    /// Initialise the driver with the surface at t = 0.  Default does nothing
    ///
    virtual void initialize( const SurfTrack& ) {}
    
    /// Draw something with OpenGL.  Default does nothing.
    ///
    virtual void display() {}
    
    /// Set velocities on each mesh vertex
    ///
    virtual void set_predicted_vertex_positions( const SurfTrack& surf, std::vector<Vec3d>& predicted_positions, double current_t, double& adaptive_dt ) = 0;
    
    /// Compute and output error.  Default does nothing.
    ///
    virtual void compute_error( const SurfTrack&, double /*current_t*/ ) {}
    
    /// Tell the driver that El Topo has finished integration.  Passes in the initial and final vertex positions, and the time 
    /// step taken.
    ///
    virtual void notify_done_integration(const std::vector<Vec3d>& /*initial_positions*/, 
                                         const std::vector<Vec3d>& /*final_positions*/, 
                                         double /*actual_dt*/ ) 
    {}
    
    /// After El Topo has done mesh improvement and defrag, this function is called to the simulation can update
    ///
    virtual void update_simulation_elements( SurfTrack& surf ) 
    {
        std::vector<VertexUpdateEvent>& vertex_history = surf.m_vertex_change_history;
        vertex_history.clear();
        
        std::vector<TriangleUpdateEvent>& triangle_history = surf.m_triangle_change_history;
        triangle_history.clear();
        
        std::vector<Vec2st>& triangle_map = surf.m_defragged_triangle_map;
        triangle_map.clear();
        
        std::vector<Vec2st>& vertex_map = surf.m_defragged_vertex_map;
        vertex_map.clear();      
    }
    
    /// Allow the driver to write something to disk at the end of a frame
    ///
    virtual void write_to_disk( char* /*output_path*/, unsigned int /*frame_num*/ ) {}
    
};



#endif

