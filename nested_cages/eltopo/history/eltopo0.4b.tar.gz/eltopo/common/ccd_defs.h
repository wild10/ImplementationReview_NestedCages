// ---------------------------------------------------------
//
//  ccd_defs.h
//  Tyson Brochu 2011
//
// ---------------------------------------------------------

#ifndef CCD_DEFS_H
#define CCD_DEFS_H

// Uncomment one of the following (cubic solver version has been tested hardest):
//

//#define USE_CUBIC_SOLVER_CCD
#define USE_TUNICATE_CCD

#endif
