
EL TOPO: TOPOLOGY-CHANGING DYNAMIC EXPLICIT SURFACES
====================================================================================

The main classes you probably want to look at are:

NonDestructiveTriMesh
DynamicSurface
SurfTrack

NonDestructiveTriMesh
---------------------
This is a basic triangle mesh class.  The fundamental data is simply a list of triangles.  It is "nondestructive" in that when you remove a triangle, it marks the triangle as deleted, but doesn't change the size of the list.  The list of triangles can then be defragged as necessary.

There is a set of auxiliary data structures containing various incidence relations.  For example, vtxtri contains, for each vertex, the set of triangles incident on that vertex.  These structures are useful for getting around the mesh, but must be updated when the set of triangles changes.

We generally defrag the list of triangles once per frame if the connectivity changes, then rebuild the auxiliary data structures.

Pretty much any underlying mesh representation should work with our system, as long as it can handle non-manifold and open meshes.

DynamicSurface
---------------------
Main data members of this class are the mesh (NonDestructiveTriMesh) and a set of vertex locations.  Additional data members include per-vertex data such as velocities and masses.

Most important member functions are collision detection and resolution functions.  This class contains enough functionality to advect a surface from one time step to the next in an intersection-free state.

This class would be sufficient for representing cloth if no mesh refinement was required.

SurfTrack
---------------------
A child class of DynamicSurface.  This class contains functions for mesh adaptivity and topological changes.


Drivers:
=====================

The dynamic surface is assigned a linear velocity per vertex by a "mesh driver".  We have a MeshDriver class which defines the interface for assigning these velocities.  This release includes several example drivers:

FaceOffDriver: Motion in the normal direction using Face Offsetting [Jiao 2007].
NormalDriver: Motion in the normal direction using vertex normals.
MeanCurvatureDriver: Motion by mean curvature.
EnrightDriver: The "Enright test" [Enright et al. 2002].
SISCCurlNoiseDriver: Curl noise [Bridson et al. 2007] with parameters set as in our SISC submission.


Other classes and files:
=====================

BroadPhase, BroadPhaseGrid and AccelerationGrid
---------------------
The acceleration structure for broad phase collision detection.  It currently consists of three regular grids, one grid each for triangles, edges and vertices.  Other broad phase approaches could be tried by subclassing the BroadPhase base class.

SubdivisionScheme
---------------------
An interface for interpolating subdivision schemes.  We currently use ButterflySubdivision for all our examples.

simulation, parser, iomesh, marching_tiles
---------------------
Functions for initializing and loading geometry.  Parser is extremely hacky.


Common:
=====================

Common is a set of files shared by our research group.  It contains all sorts of useful things.  Most notably:

vec: A templated n-dimensional vector class.  I use Vec3d (a vector of 3 doubles) all over the place.
mat: A templated matrix class.
gluvi: An OpenGL GUI.
blas_wrapper and lapack_wrapper: Cross-platform interfaces to BLAS and LAPACK functions.



