// ---------------------------------------------------------
//
//  simulation.h
//
//  Simulation class.  Mainly just timekeeping.
//
// ---------------------------------------------------------

#ifndef SIMULATION_H
#define SIMULATION_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// ---------------------------------------------------------
///
///  Simulation parameters
///
// ---------------------------------------------------------

class Simulation
{
public:
   
   /// Specify a target time step and optional end time
   ///
   Simulation( double in_dt, double in_max_t = 1e30 );
   
   /// simulation time step size
   ///
   double dt;

   /// end time
   ///
   double max_t;
   
   /// frame time step size (1/fps)
   ///
   double frame_dt;
   
   /// current simulation time
   ///
   double curr_t;

   /// current frame
   ///
   unsigned int curr_frame;

   /// whether we're currently running an entire simulation
   ///
   bool running;

   /// whether we're currently running a single timestep of the simulation
   ///
   bool currently_advancing_simulation;
   
};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------

inline Simulation::Simulation( double in_dt, double in_max_t ) :
   dt(in_dt),
   max_t(in_max_t),
   frame_dt(in_dt),
   curr_t(0),
   curr_frame(0),
   running(false),
   currently_advancing_simulation(false)
{
}

#endif



