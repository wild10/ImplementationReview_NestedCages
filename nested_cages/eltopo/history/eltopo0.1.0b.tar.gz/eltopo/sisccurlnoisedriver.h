// ---------------------------------------------------------
//
//  sisccurlnoisedriver.h
//
//  Mesh driver for divergence-free, pseuo-random velocity
//
// ---------------------------------------------------------

#ifndef SISCCURLNOISEDRIVER_H
#define SISCCURLNOISEDRIVER_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <curlnoise.h>
#include <noise.h>
#include <meshdriver.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class DynamicSurface;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Driver for the curl noise example in the SISC paper.
///
// ---------------------------------------------------------

struct SISCCurlNoiseDriver: public CurlNoise3, public MeshDriver
{
   
   /// Default constructor
   ///
   SISCCurlNoiseDriver(void);
   
   /// Initializer
   ///
   void initialize( const DynamicSurface& surf );

   //
   // Virtual functions 
   //
   
   void display( const DynamicSurface& ) {}
   bool seed_particles(std::vector<Vec3d> &x, double dt) const { return true; }   
   void advance_time(double dt) {}

   /// z-component of noise vector (x and y are 0)
   ///
   double noise2(double x, double y, double z) const { return noise(z-203.994, x+169.47, y-205.31); }
   
   /// Take the curl of this function to get velocity
   ///
   Vec3d potential(double x, double y, double z) const;
   
   /// Set velocity on each mesh vertex
   ///
   void set_surface_velocity( const DynamicSurface& surf, 
                              std::vector<Vec3d>& out_velocity, 
                              double current_t, 
                              double& dt );

   /// Compute and output error (difference between current volume and initial volume)
   ///
   void compute_error( const DynamicSurface& surf, double current_t );
   
   /// Parameters for each scale of noise
   ///
   std::vector<double> noise_lengthscale, noise_gain;
   
   /// Noise generator
   /// 
   FlowNoise3 noise;
   
   /// Volume enclosed by surface at t = 0.  Compare to volume at current time to get error.
   ///
   double m_initial_volume;
   
};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------


#endif
