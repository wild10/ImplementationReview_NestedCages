// ---------------------------------------------------------
//
//  dynamicsurface.cpp
//  
//  A triangle mesh with associated vertex locations and 
//  velocities.  Collision detection and solving.
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <dynamicsurface.h>

#include <vector>
#include <deque>
#include <queue>

#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

#include <vec.h>
#include <mat.h>
#include <array3.h>
#include <collisionqueries.h>
#include <predicates.h>
#include <gluvi.h>
#include <ctime>
#include <nondestructivetrimesh.h>
#include <iomesh.h>
#include <broadphasegrid.h>
#include <simulation.h>
#include <wallclocktime.h>

#include <cassert>

#include <sparse_matrix.h>
#include <krylov_solvers.h>

#include <fstream>

#include <lapack_wrapper.h>

#include <array2.h>

#include <meshdriver.h>

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Extern globals
// ---------------------------------------------------------

/// Indices of any intersecting triangles
extern std::vector<unsigned int> g_intersecting_triangles;

/// Used to classify a vertex as smooth, ridge or corner
extern double G_EIGENVALUE_RANK_RATIO;

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Add a collision to the list as long as it doesn't have the same vertices as any other collisions in the list.
///
// ---------------------------------------------------------

static void add_unique_collision( std::vector<Collision>& collisions, const Collision& new_collision )
{
   for ( std::vector<Collision>::iterator iter = collisions.begin(); iter != collisions.end(); ++iter )
   {
      if ( iter->same_vertices( new_collision ) )
      {
         return;
      }
   }
   
   collisions.push_back( new_collision );
}

// ---------------------------------------------------------
///
/// Helper function: multiply transpose(A) * D * B
///
// ---------------------------------------------------------

static void AtDB(const SparseMatrixDynamicCSR &A, const double* diagD, const SparseMatrixDynamicCSR &B, SparseMatrixDynamicCSR &C)
{
   assert(A.m==B.m);
   C.resize(A.n, B.n);
   C.set_zero();
   for(int k=0; k<A.m; ++k)
   {
      const DynamicSparseVector& r = A.row[k];
      
      for( DynamicSparseVector::const_iterator p=r.begin(); p != r.end(); ++p )
      {
         int i = p->index;
         double multiplier = p->value * diagD[k];
         C.add_sparse_row( i, B.row[k], multiplier );
      }
   }
}

// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// DynamicSurface constructor.  Copy triangles and vertex locations.
///
// ---------------------------------------------------------

DynamicSurface::DynamicSurface( const std::vector<Vec3d>& vertex_positions, 
                                const std::vector<Vec3ui>& triangles,
                                const std::vector<double>& masses,
                                double in_triangle_area, 
                                double in_proximity_epsilon,
                                bool in_collision_safety) :
   m_min_triangle_area( in_triangle_area ),
   m_proximity_epsilon( in_proximity_epsilon ),
   m_verbose( false ),
   m_collision_safety( in_collision_safety ),
   m_positions(0), m_newpositions(0), m_velocities(0), m_masses(0), m_reference_positions(0),
   m_mesh(),
   m_broad_phase( new BroadPhaseGrid() )
{
   
   std::cout << "constructing dynamic surface" << std::endl;
  
   for(unsigned int i = 0; i < vertex_positions.size(); i++)
   {
      m_positions.push_back( vertex_positions[i] );
		m_newpositions.push_back( vertex_positions[i] );
      m_velocities.push_back( Vec3d(0,0,0) );
      m_masses.push_back( masses[i] );
      
      m_reference_positions.push_back( vertex_positions[i] );
   }
   
   for(unsigned int i = 0; i < triangles.size(); i++)
   {
      m_mesh.tris.push_back( triangles[i] );
   }
   
   std::cout << "vs: " << m_positions.size() << std::endl;
   std::cout << "tris: " << m_mesh.tris.size() << std::endl;
   
   std::cout << "constructed dynamic surface" << std::endl;
}


// ---------------------------------------------------------
///
/// Compute rank of the quadric metric tensor at a vertex
///
// ---------------------------------------------------------

unsigned int DynamicSurface::classify_vertex( unsigned int v )
{     
   if ( m_mesh.vtxtri[v].size() == 0 )     { return 0; }
   
   const std::vector<unsigned int>& incident_triangles = m_mesh.vtxtri[v];
   
   std::vector< Vec3d > N;
   std::vector< double > W;
   
   for ( unsigned int i = 0; i < incident_triangles.size(); ++i )
   {
      unsigned int triangle_index = incident_triangles[i];
      N.push_back( get_triangle_normal(triangle_index) );
      W.push_back( get_triangle_area(triangle_index) );
   }
   
   Mat33d A(0,0,0,0,0,0,0,0,0);
   
   for ( unsigned int i = 0; i < N.size(); ++i )
   {
      A(0,0) += N[i][0] * W[i] * N[i][0];
      A(1,0) += N[i][1] * W[i] * N[i][0];
      A(2,0) += N[i][2] * W[i] * N[i][0];
      
      A(0,1) += N[i][0] * W[i] * N[i][1];
      A(1,1) += N[i][1] * W[i] * N[i][1];
      A(2,1) += N[i][2] * W[i] * N[i][1];
      
      A(0,2) += N[i][0] * W[i] * N[i][2];
      A(1,2) += N[i][1] * W[i] * N[i][2];
      A(2,2) += N[i][2] * W[i] * N[i][2];
   }
   
   // get eigen decomposition
   double eigenvalues[3];
   double work[9];
   int info = ~0, n = 3, lwork = 9;
   LAPACK::get_eigen_decomposition( &n, A.a, &n, eigenvalues, work, &lwork, &info );
   
   if ( info != 0 )
   {
      std::cout << "Eigen decomp failed.  Incident triangles: " << std::endl;
      for ( unsigned int i = 0; i < W.size(); ++i )
      {
         std::cout << "normal: ( " << N[i] << " )    ";  
         std::cout << "area: " << W[i] << std::endl;
      }
      return 4;
   }
   
   // compute rank of primary space
   unsigned int rank = 0;
   for ( unsigned int i = 0; i < 3; ++i )
   {
      if ( eigenvalues[i] > G_EIGENVALUE_RANK_RATIO * eigenvalues[2] )
      {
         ++rank;
      }
   }
   
   return rank;
   
}



// ---------------------------------------------------------
///
/// Add a triangle to the surface.  Update the underlying TriMesh and acceleration grid. 
///
// ---------------------------------------------------------

unsigned int DynamicSurface::add_triangle( const Vec3ui& t )
{
   unsigned int new_triangle_index = m_mesh.tris.size();
   m_mesh.nondestructive_add_triangle( t );
   
   // Add to the triangle grid
   Vec3d low, high;
   triangle_static_bounds( new_triangle_index, low, high );
   m_broad_phase->add_triangle( new_triangle_index, low, high );
   
   // Add edges to grid as well
   unsigned int new_edge_index = m_mesh.get_edge( t[0], t[1] );
   assert( new_edge_index != m_mesh.edges.size() );
   edge_static_bounds( new_edge_index, low, high );
   m_broad_phase->add_edge( new_edge_index, low, high );
   
   new_edge_index = m_mesh.get_edge( t[1], t[2] );
   assert( new_edge_index != m_mesh.edges.size() );   
   edge_static_bounds( new_edge_index, low, high );
   m_broad_phase->add_edge( new_edge_index, low, high );
   
   new_edge_index = m_mesh.get_edge( t[2], t[0] );
   assert( new_edge_index != m_mesh.edges.size() );   
   edge_static_bounds( new_edge_index, low, high );
   m_broad_phase->add_edge( new_edge_index, low, high );
   
   return new_triangle_index;
}


// ---------------------------------------------------------
///
/// Remove a triangle from the surface.  Update the underlying TriMesh and acceleration grid. 
///
// ---------------------------------------------------------

void DynamicSurface::remove_triangle(unsigned int t)
{
   m_mesh.nondestructive_remove_triangle( t );
   m_broad_phase->remove_triangle( t );
}


// ---------------------------------------------------------
///
/// Add a vertex to the surface.  Update the acceleration grid. 
///
// ---------------------------------------------------------

unsigned int DynamicSurface::add_vertex( const Vec3d& new_vertex_position, 
                                         const Vec3d& new_vertex_velocity, 
                                         const Vec3d& new_vertex_reference_position, 
                                         double new_vertex_mass )
{
   m_positions.push_back( new_vertex_position );
   m_newpositions.push_back( new_vertex_position );
   m_velocities.push_back( new_vertex_velocity );
   m_masses.push_back( new_vertex_mass );
   
   m_reference_positions.push_back( new_vertex_reference_position );
     
   unsigned int new_vertex_index = m_mesh.nondestructive_add_vertex( );

   assert( new_vertex_index == m_positions.size() - 1 );
      
   m_broad_phase->add_vertex( new_vertex_index, m_positions[new_vertex_index], m_positions[new_vertex_index] );       
   return new_vertex_index;
}


// ---------------------------------------------------------
///
/// Remove a vertex from the surface.  Update the acceleration grid. 
///
// ---------------------------------------------------------

void DynamicSurface::remove_vertex( unsigned int vertex_index )
{
   m_mesh.nondestructive_remove_vertex( vertex_index );
   m_broad_phase->remove_vertex( vertex_index );
   
   m_positions[ vertex_index ] = Vec3d( 0.0, 0.0, 0.0 );
   m_newpositions[ vertex_index ] = Vec3d( 0.0, 0.0, 0.0 );
   m_reference_positions[ vertex_index ] = Vec3d( 0.0, 0.0, 0.0 );

}


// ---------------------------------------------------------
///
/// Remove all vertices not incident on any triangles.
///
// ---------------------------------------------------------

void DynamicSurface::clear_deleted_vertices( )
{

   unsigned int j = 0;
   
   for ( unsigned int i = 0; i < m_positions.size(); ++i )
   {
      std::vector<unsigned int>& inc_tris = m_mesh.vtxtri[i];

      if ( inc_tris.size() != 0 )
      {
         m_positions[j] = m_positions[i];
         m_newpositions[j] = m_newpositions[i];
         m_velocities[j] = m_velocities[i];
         m_masses[j] = m_masses[i];
         m_reference_positions[j] = m_reference_positions[i];
         
         for ( unsigned int t = 0; t < inc_tris.size(); ++t )
         {
            Vec3ui& triangle = m_mesh.tris[ inc_tris[t] ];
            
            if ( triangle[0] == i ) { triangle[0] = j; }
            if ( triangle[1] == i ) { triangle[1] = j; }
            if ( triangle[2] == i ) { triangle[2] = j; }            
         }
         
         ++j;
      }

   }
      
   m_positions.resize(j);
   m_newpositions.resize(j);
   m_velocities.resize(j);
   m_masses.resize(j);
   m_reference_positions.resize(j);

}


// ---------------------------------------------------------
///
/// Apply an impulse between two edges 
///
// ---------------------------------------------------------

void DynamicSurface::apply_edge_edge_impulse( const Vec2ui& edge0, 
                                              const Vec2ui& edge1,
                                              double s0, 
                                              double s2, 
                                              Vec3d& direction, 
                                              double magnitude )
{
   Vec3d& v0 = m_velocities[edge0[0]];
   Vec3d& v1 = m_velocities[edge0[1]];
   Vec3d& v2 = m_velocities[edge1[0]];
   Vec3d& v3 = m_velocities[edge1[1]];
   double inv_m0 = m_masses[edge0[0]] < 100 ? 1 / m_masses[edge0[0]] : 0.0;
   double inv_m1 = m_masses[edge0[1]] < 100 ? 1 / m_masses[edge0[1]] : 0.0;
   double inv_m2 = m_masses[edge1[0]] < 100 ? 1 / m_masses[edge1[0]] : 0.0;
   double inv_m3 = m_masses[edge1[1]] < 100 ? 1 / m_masses[edge1[1]] : 0.0;
    
   double s1 = 1.0 - s0;
   double s3 = 1.0 - s2;
   double i = magnitude/(s0*s0*inv_m0 + s1*s1*inv_m1 + s2*s2*inv_m2 + s3*s3*inv_m3);
   
   v0 += i*s0*inv_m0 * direction;
   v1 += i*s1*inv_m1 * direction;
   v2 -= i*s2*inv_m2 * direction;
   v3 -= i*s3*inv_m3 * direction;
}

// ---------------------------------------------------------
///
/// Apply an impulse between a point and a triangle
///
// ---------------------------------------------------------

void DynamicSurface::apply_triangle_point_impulse( const Vec3ui& tri, 
                                                   unsigned int v,
                                                   double s1, 
                                                   double s2, 
                                                   double s3, 
                                                   Vec3d& direction, 
                                                   double magnitude )
{

   Vec3d& v0 = m_velocities[v];
   Vec3d& v1 = m_velocities[tri[0]];
   Vec3d& v2 = m_velocities[tri[1]];
   Vec3d& v3 = m_velocities[tri[2]];
   double inv_m0 = m_masses[v] < 100 ? 1 / m_masses[v] : 0.0;
   double inv_m1 = m_masses[tri[0]] < 100 ? 1 / m_masses[tri[0]] : 0.0;
   double inv_m2 = m_masses[tri[1]] < 100 ? 1 / m_masses[tri[1]] : 0.0;
   double inv_m3 = m_masses[tri[2]] < 100 ? 1 / m_masses[tri[2]] : 0.0;

   double i = magnitude / (inv_m0 + s1*s1*inv_m1 + s2*s2*inv_m2 + s3*s3*inv_m3);

   v0 += (i*inv_m0) * direction;
   v1 -= (i*s1*inv_m1) * direction;
   v2 -= (i*s2*inv_m2) * direction;
   v3 -= (i*s3*inv_m3) * direction;
}
 


// ---------------------------------------------------------
///
/// Detect all triangle-point proximities and apply repulsion impulses
///
// ---------------------------------------------------------

void DynamicSurface::handle_triangle_point_proximities( double dt )
{
   std::cout << "----------------------handling triangle-point proximities ----------------------" << std::endl;
   
   unsigned int point_triangle_proximities = 0;
   
   for ( unsigned int i = 0; i < m_mesh.tris.size(); ++i )
   {
      const Vec3ui& tri = m_mesh.tris[i];
      
      if ( tri[0] == tri[1] )    { continue; }


      Vec3d low, high;
      triangle_static_bounds( i, low, high );
      std::vector<unsigned int> potential_vertex_collisions;
      m_broad_phase->get_potential_vertex_collisions( low, high, potential_vertex_collisions );
      
      for ( unsigned int j = 0; j < potential_vertex_collisions.size(); ++j )
      {
         unsigned int v = potential_vertex_collisions[j];
   
         if(tri[0] != v && tri[1] != v && tri[2] != v)
         {
            double distance, s1, s2, s3;
            Vec3d normal;
            
            check_point_triangle_proximity( m_positions[v], m_positions[tri[0]], m_positions[tri[1]], m_positions[tri[2]],
                                           distance, s1, s2, s3, normal );
            
            if(distance < m_proximity_epsilon)
            {
               
               double relvel = dot(normal, m_velocities[v] - (s1*m_velocities[tri[0]] + s2*m_velocities[tri[1]] + s3*m_velocities[tri[2]]));
               double desired_relative_velocity = ( m_proximity_epsilon - distance ) / dt;
               double impulse = (desired_relative_velocity - relvel);
               
               apply_triangle_point_impulse( tri, v, s1, s2, s3, normal, impulse);
               
               ++point_triangle_proximities;
               
            }
         }      
      }
   }

   std::cout << "point_triangle_proximities: " << point_triangle_proximities << std::endl;
   
}


// ---------------------------------------------------------
///
/// Detect all edge-edge proximities and apply repulsion impulses
///
// ---------------------------------------------------------

void DynamicSurface::handle_edge_edge_proximities( double dt )
{
   std::cout << "----------------------handling edge-edge proximities ----------------------" << std::endl;
   
   unsigned int edge_edge_proximities = 0;
   
   for ( unsigned int i = 0; i < m_mesh.edges.size(); ++i )
   {
      const Vec2ui& e0 = m_mesh.edges[ i ];
      
      if ( e0[0] == e0[1] ) { continue; }
      
      Vec3d low, high;
      edge_static_bounds( i, low, high );
      std::vector<unsigned int> potential_collisions;
      m_broad_phase->get_potential_edge_collisions( low, high, potential_collisions );
      
      for ( unsigned int j = 0; j < potential_collisions.size(); ++j )
      {
         if ( potential_collisions[j] <= i )    { continue; }
         
         const Vec2ui& e1 = m_mesh.edges[ potential_collisions[j] ];
         
         if ( e1[0] == e1[1] )   { continue; }
         
         if(e0[0] != e1[0] && e0[0] != e1[1] && e0[1] != e1[0] && e0[1] != e1[1])
         {
            double distance, s0, s2;
            Vec3d normal;
            
            check_edge_edge_proximity(m_positions[e0[0]], m_positions[e0[1]], m_positions[e1[0]], m_positions[e1[1]],
                                      distance, s0, s2, normal);
            
            if( distance < m_proximity_epsilon )
            {
               ++edge_edge_proximities;
               
               double relvel = dot(normal, s0*m_velocities[e0[0]] + (1.0-s0)*m_velocities[e0[1]] - (s2*m_velocities[e1[0]] + (1.0-s2)*m_velocities[e1[1]]));
               double desired_relative_velocity = ( m_proximity_epsilon - distance ) / dt;               
               double impulse = ( desired_relative_velocity - relvel );
               
               apply_edge_edge_impulse( e0, e1, s0, s2, normal, impulse);
            }
         }
      }
   }
   
   std::cout << "edge_edge_proximities: " << edge_edge_proximities << std::endl;
   
}


// ---------------------------------------------------------
///
/// Add point-triangle collision candidates for a specified triangle
///
// ---------------------------------------------------------

void DynamicSurface::add_triangle_candidates(unsigned int t, CollisionCandidateSet& collision_candidates)
{
   Vec3d tmin, tmax;
   triangle_continuous_bounds(t, tmin, tmax);
   tmin -= Vec3d( m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon );
   tmax += Vec3d( m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon );
   
   std::vector<unsigned int> candidate_vertices;
   m_broad_phase->get_potential_vertex_collisions( tmin, tmax, candidate_vertices );
   
   for(unsigned int j = 0; j < candidate_vertices.size(); j++)
   {
      add_to_collision_candidates( collision_candidates, Vec3ui(t, candidate_vertices[j], 0) );
   }
   
}

// ---------------------------------------------------------
///
/// Add edge-edge collision candidates for a specified edge
///
// ---------------------------------------------------------

void DynamicSurface::add_edge_candidates(unsigned int e, CollisionCandidateSet& collision_candidates)
{
   Vec3d emin, emax;
   edge_continuous_bounds(e, emin, emax);
   emin -= Vec3d( m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon );
   emax += Vec3d( m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon );
   
   std::vector<unsigned int> candidate_edges;
   m_broad_phase->get_potential_edge_collisions( emin, emax, candidate_edges);
   
   for(unsigned int j = 0; j < candidate_edges.size(); j++)
   {
      add_to_collision_candidates( collision_candidates, Vec3ui(e, candidate_edges[j], 1) );
   }
}

// ---------------------------------------------------------
///
/// Add point-triangle collision candidates for a specified vertex
///
// ---------------------------------------------------------

void DynamicSurface::add_point_candidates(unsigned int v, CollisionCandidateSet& collision_candidates)
{
   Vec3d vmin, vmax;
   vertex_continuous_bounds(v, vmin, vmax);
   vmin -= Vec3d( m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon );
   vmax += Vec3d( m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon );
   
   std::vector<unsigned int> candidate_triangles;
   m_broad_phase->get_potential_triangle_collisions( vmin, vmax, candidate_triangles);
   
   for(unsigned int j = 0; j < candidate_triangles.size(); j++)
   {
      add_to_collision_candidates( collision_candidates, Vec3ui(candidate_triangles[j], v, 0) );
   }
}

// ---------------------------------------------------------
///
/// Add collision candidates for a specified vertex and all elements incident on the vertex
///
// ---------------------------------------------------------

void DynamicSurface::add_point_update_candidates(unsigned int v, CollisionCandidateSet& collision_candidates)
{
   add_point_candidates(v, collision_candidates);
   
   std::vector<unsigned int>& incident_triangles = m_mesh.vtxtri[v];
   std::vector<unsigned int>& incident_edges = m_mesh.vtxedge[v];
   
   for(unsigned int i = 0; i < incident_triangles.size(); i++)
      add_triangle_candidates(incident_triangles[i], collision_candidates);
   
   for(unsigned int i = 0; i < incident_edges.size(); i++)
      add_edge_candidates(incident_edges[i], collision_candidates);
}


// ---------------------------------------------------------
///
/// Perform one sweep of impulse collision handling, only for "deformable" vertices against "solid" triangles
///
// ---------------------------------------------------------

void DynamicSurface::handle_point_vs_solid_triangle_collisions( double dt )
{
   std::cout << "---------------------- handling point-tri collisions ----------------------" << std::endl;
   
   for(unsigned int i = 0; i < m_mesh.tris.size(); i++)
   {
      CollisionCandidateSet triangle_collision_candidates;
      add_triangle_candidates(i, triangle_collision_candidates);
      
      while( false == triangle_collision_candidates.empty() )
      {
         CollisionCandidateSet::iterator iter = triangle_collision_candidates.begin();
         Vec3ui candidate = *iter;
         triangle_collision_candidates.erase(iter);
      
         unsigned int t = candidate[0];
         Vec3ui tri = m_mesh.tris[t];
         unsigned int v = candidate[1];
         
         if ( m_masses[v] < 100 && m_masses[tri[0]] > 100 && m_masses[tri[1]] > 100 && m_masses[tri[2]] > 100 )
         {
         
            if(tri[0] != v && tri[1] != v && tri[2] != v)
            {
               double time, s1, s2, s3, rel_disp;
               Vec3d normal;
                            
               Vec3ui sorted_tri = sort_triangle( tri );
               
               if ( point_triangle_collision( m_positions[v], m_newpositions[v],
                                             m_positions[sorted_tri[0]], m_newpositions[sorted_tri[0]],
                                             m_positions[sorted_tri[1]], m_newpositions[sorted_tri[1]],
                                             m_positions[sorted_tri[2]], m_newpositions[sorted_tri[2]],
                                             s1, s2, s3,
                                             normal,
                                             time, rel_disp ) )                                 
               {
                  
                  double relvel = rel_disp / dt;
                  
                  apply_triangle_point_impulse(sorted_tri, v, s1, s2, s3, normal, -relvel);
                                  
                  m_newpositions[v] = m_positions[v] + dt*m_velocities[v];
                  m_newpositions[tri[0]] = m_positions[tri[0]] + dt*m_velocities[tri[0]];
                  m_newpositions[tri[1]] = m_positions[tri[1]] + dt*m_velocities[tri[1]];
                  m_newpositions[tri[2]] = m_positions[tri[2]] + dt*m_velocities[tri[2]];
                  
                  update_continuous_broad_phase( v );
                  update_continuous_broad_phase( tri[0] );
                  update_continuous_broad_phase( tri[1] );
                  update_continuous_broad_phase( tri[2] );             
               }
                  
            }
         }
      }      
   }
   
}


// ---------------------------------------------------------
///
/// Detect all continuous collisions and apply impulses to prevent them.
/// Return true if all collisions were resolved.
///
// ---------------------------------------------------------

bool DynamicSurface::handle_collisions(double dt)
{
   
   const unsigned int MAX_PASS = 3;
   const unsigned int MAX_CANDIDATES = (unsigned int) 1e+6; 
   
   CollisionCandidateSet update_collision_candidates;
   
   if ( MAX_PASS == 0 )
   {
      return false;
   }
   
   bool collision_found = true;
   bool candidate_overflow = false;

   for ( unsigned int pass = 0; ( collision_found && (pass < MAX_PASS) ); ++pass )
   {
      collision_found = false;
      
      std::cout << "---------------------- handling point-tri collisions ----------------------" << std::endl;
      
      for(unsigned int i = 0; i < m_mesh.tris.size(); i++)
      {
         CollisionCandidateSet triangle_collision_candidates;
         add_triangle_candidates(i, triangle_collision_candidates);
         
         while( false == triangle_collision_candidates.empty() )
         {
            CollisionCandidateSet::iterator iter = triangle_collision_candidates.begin();
            Vec3ui candidate = *iter;
            triangle_collision_candidates.erase(iter);
            
            unsigned int t = candidate[0];
            Vec3ui tri = m_mesh.tris[t];
            unsigned int v = candidate[1];
            
            if(tri[0] != v && tri[1] != v && tri[2] != v)
            {
               double time, s1, s2, s3, rel_disp;
               Vec3d normal;              

               Vec3ui sorted_tri = sort_triangle( tri );

               if ( point_triangle_collision( m_positions[v], m_newpositions[v],
                                              m_positions[sorted_tri[0]], m_newpositions[sorted_tri[0]],
                                              m_positions[sorted_tri[1]], m_newpositions[sorted_tri[1]],
                                              m_positions[sorted_tri[2]], m_newpositions[sorted_tri[2]],
                                              s1, s2, s3,
                                              normal,
                                              time, rel_disp ) )               
               {
                                    
                  double relvel = rel_disp / dt;
                 
                  apply_triangle_point_impulse(sorted_tri, v, s1, s2, s3, normal, -relvel);
                  
                  if ( m_verbose ) std::cout << "(PT) time: " << time << ", relative velocity before: " << relvel;
                  
                  double relvel_after = dot(normal, m_velocities[v] - (s1*m_velocities[sorted_tri[0]] + s2*m_velocities[sorted_tri[1]] + s3*m_velocities[sorted_tri[2]]));
                  
                  if ( m_verbose ) std::cout << " and relative velocity after: " << relvel_after << std::endl;
                  
                  m_newpositions[v] = m_positions[v] + dt*m_velocities[v];
                  m_newpositions[tri[0]] = m_positions[tri[0]] + dt*m_velocities[tri[0]];
                  m_newpositions[tri[1]] = m_positions[tri[1]] + dt*m_velocities[tri[1]];
                  m_newpositions[tri[2]] = m_positions[tri[2]] + dt*m_velocities[tri[2]];
                  
                  update_continuous_broad_phase( v  );
                  update_continuous_broad_phase( tri[0] );
                  update_continuous_broad_phase( tri[1] );
                  update_continuous_broad_phase( tri[2] );
                                    
                  if ( pass == MAX_PASS - 1 )
                  {
                     if ( update_collision_candidates.size() < MAX_CANDIDATES )
                     {
                        add_point_update_candidates(v, update_collision_candidates);
                        add_point_update_candidates(tri[0], update_collision_candidates);
                        add_point_update_candidates(tri[1], update_collision_candidates);
                        add_point_update_candidates(tri[2], update_collision_candidates);
                     }
                     else
                     {
                        candidate_overflow = true;
                     }
                  }
                  
                  collision_found = true;
                  
               }            
            }
         }      
      }
         
      std::cout << "---------------------- handling edge-edge collisions ----------------------" << std::endl;
      
      m_verbose = false;
      
      for(unsigned int i = 0; i < m_mesh.edges.size(); i++)
      {
         CollisionCandidateSet edge_collision_candidates;
         add_edge_candidates(i, edge_collision_candidates);
                           
         while ( false == edge_collision_candidates.empty() )
         {
            CollisionCandidateSet::iterator iter = edge_collision_candidates.begin();
            Vec3ui candidate = *iter;
            edge_collision_candidates.erase(iter);
                     
            Vec2ui e0 = m_mesh.edges[candidate[0]];
            Vec2ui e1 = m_mesh.edges[candidate[1]];
                                    
            assert( candidate[0] == i );
            
            if ( candidate[1] <= i ) { continue; }
            
            if ( e0[0] == e0[1] ) { continue; }
            if ( e1[0] == e1[1] ) { continue; }
               
            if(e0[0] != e1[0] && e0[0] != e1[1] && e0[1] != e1[0] && e0[1] != e1[1])
            {
               double time, s0, s2, rel_disp;
               Vec3d normal;

               if ( e0[1] < e0[0] ) { swap( e0[0], e0[1] ); }
               if ( e1[1] < e1[0] ) { swap( e1[0], e1[1] ); }
               
               if ( ( e0[1] < e0[0] ) || ( e1[1] < e1[0] ) )
               {
                  std::cout << e0 << std::endl;
                  std::cout << e1 << std::endl;
                  assert(0);
               }
               
               if ( segment_segment_collision( m_positions[e0[0]], m_newpositions[e0[0]],
                                               m_positions[e0[1]], m_newpositions[e0[1]],
                                               m_positions[e1[0]], m_newpositions[e1[0]],
                                               m_positions[e1[1]], m_newpositions[e1[1]],
                                               s0, s2,
                                               normal,
                                               time, rel_disp ) )
               {
                  
                  double relvel = rel_disp / dt;
                  
                  if ( m_verbose ) 
                  {
                     std::cout << "(EE) time: " << time << ", relative velocity before: " << relvel;
                     std::cout << ", normal: " << normal;
                  }
                  
                  apply_edge_edge_impulse(e0, e1, s0, s2, normal, -relvel);
                  
                  double relvel_after = dot(normal, s0*m_velocities[e0[0]] + (1.0-s0)*m_velocities[e0[1]] - (s2*m_velocities[e1[0]] + (1.0-s2)*m_velocities[e1[1]]));
                  
                  if ( m_verbose ) std::cout << " and relative velocity after: " << relvel_after << std::endl;

                  m_newpositions[e0[0]] = m_positions[e0[0]] + dt*m_velocities[e0[0]];
                  m_newpositions[e0[1]] = m_positions[e0[1]] + dt*m_velocities[e0[1]];
                  m_newpositions[e1[0]] = m_positions[e1[0]] + dt*m_velocities[e1[0]];
                  m_newpositions[e1[1]] = m_positions[e1[1]] + dt*m_velocities[e1[1]];
                  
                  update_continuous_broad_phase( e0[0] );
                  update_continuous_broad_phase( e0[1] );
                  update_continuous_broad_phase( e1[0] );
                  update_continuous_broad_phase( e1[1] );
                                    
                  if ( pass == MAX_PASS - 1 )
                  {
                     if ( update_collision_candidates.size() < MAX_CANDIDATES )
                     {
                        add_point_update_candidates(e0[0], update_collision_candidates);
                        add_point_update_candidates(e0[1], update_collision_candidates);
                        add_point_update_candidates(e1[0], update_collision_candidates);
                        add_point_update_candidates(e1[1], update_collision_candidates);
                     }
                     else
                     {
                        candidate_overflow = true;
                     }
                  }
                  
                  collision_found = true;
                  
                  m_verbose = false;
                  
               }               
            }
         }      
      }
         
   }
   
   std::cout << "---------------------- unique-ifying update_collision_candidates ----------------------" << std::endl;
   
   {
      CollisionCandidateSet::iterator new_end = std::unique( update_collision_candidates.begin(), update_collision_candidates.end() );
      update_collision_candidates.erase( new_end, update_collision_candidates.end() );
   }
   
   std::cout << "---------------------- handling new collisions ----------------------" << std::endl;
   std::cout << "collision candidates remaining: " << update_collision_candidates.size() << std::endl;  
   
   unsigned int n = update_collision_candidates.size();
   unsigned int c = 0;
   
   while( !update_collision_candidates.empty() && c < (5 * n) )
   {

      c++;
      CollisionCandidateSet::iterator iter = update_collision_candidates.begin();
      Vec3ui candidate = *iter;
      update_collision_candidates.erase(iter);
            
      if(candidate[2]==0)
      {
         unsigned int t = candidate[0];
         const Vec3ui& tri = m_mesh.tris[t];
         unsigned int v = candidate[1];
         
         if(tri[0] != v && tri[1] != v && tri[2] != v)
         {
            double time, s1, s2, s3, rel_disp;
            Vec3d normal;
            
            Vec3ui sorted_tri = sort_triangle( tri );            
            
            if ( point_triangle_collision( m_positions[v], m_newpositions[v],
                                          m_positions[sorted_tri[0]], m_newpositions[sorted_tri[0]],
                                          m_positions[sorted_tri[1]], m_newpositions[sorted_tri[1]],
                                          m_positions[sorted_tri[2]], m_newpositions[sorted_tri[2]],
                                          s1, s2, s3,
                                          normal,
                                          time, rel_disp ) )               
            {

               double relvel = rel_disp / dt;
               
               if ( m_verbose ) std::cout << "VT ( " << v << " " << tri << " ) relative velocity before: " << relvel; 
               
               apply_triangle_point_impulse( sorted_tri, v, s1, s2, s3, normal, -relvel);
               
               double relvel_after = dot(normal, m_velocities[v] - (s1*m_velocities[tri[0]] + s2*m_velocities[tri[1]] + s3*m_velocities[tri[2]]));
               
               if ( m_verbose ) std::cout << " and relative velocity after: " << relvel_after << std::endl;

               m_newpositions[v] = m_positions[v] + dt*m_velocities[v];
               m_newpositions[tri[0]] = m_positions[tri[0]] + dt*m_velocities[tri[0]];
               m_newpositions[tri[1]] = m_positions[tri[1]] + dt*m_velocities[tri[1]];
               m_newpositions[tri[2]] = m_positions[tri[2]] + dt*m_velocities[tri[2]];
               
               update_continuous_broad_phase( v  );
               update_continuous_broad_phase( tri[0] );
               update_continuous_broad_phase( tri[1] );
               update_continuous_broad_phase( tri[2] );
               
               if ( update_collision_candidates.size() < MAX_CANDIDATES )
               {
                  add_point_update_candidates(v, update_collision_candidates);
                  add_point_update_candidates(tri[0], update_collision_candidates);
                  add_point_update_candidates(tri[1], update_collision_candidates);
                  add_point_update_candidates(tri[2], update_collision_candidates);
               }
               else
               {
                  candidate_overflow = true;
               }
            }
         }
      }
      else
      {
         Vec2ui e0 = m_mesh.edges[candidate[0]];
         Vec2ui e1 = m_mesh.edges[candidate[1]];
         if(e0[0] != e1[0] && e0[0] != e1[1] && e0[1] != e1[0] && e0[1] != e1[1])
         {
            if ( e0[1] < e0[0] ) { swap( e0[0], e0[1] ); }
            if ( e1[1] < e1[0] ) { swap( e1[0], e1[1] ); }
            
            double time, s0, s2, rel_disp;
            Vec3d normal;
            
            if ( segment_segment_collision( m_positions[e0[0]], m_newpositions[e0[0]],
                                           m_positions[e0[1]], m_newpositions[e0[1]],
                                           m_positions[e1[0]], m_newpositions[e1[0]],
                                           m_positions[e1[1]], m_newpositions[e1[1]],
                                           s0, s2,
                                           normal,
                                           time, rel_disp ) )
            {

               double relvel = rel_disp / dt;
               
               if ( m_verbose ) std::cout << "EE relative velocity before: " << relvel;
               
               apply_edge_edge_impulse(e0, e1, s0, s2, normal, -relvel);
               
               double relvel_after = dot(normal, s0*m_velocities[e0[0]] + (1.0-s0)*m_velocities[e0[1]] - (s2*m_velocities[e1[0]] + (1.0-s2)*m_velocities[e1[1]]));
               
               if ( m_verbose ) std::cout << " and relative velocity after: " << relvel_after << std::endl;            
                              
               m_newpositions[e0[0]] = m_positions[e0[0]] + dt*m_velocities[e0[0]];
               m_newpositions[e0[1]] = m_positions[e0[1]] + dt*m_velocities[e0[1]];
               m_newpositions[e1[0]] = m_positions[e1[0]] + dt*m_velocities[e1[0]];
               m_newpositions[e1[1]] = m_positions[e1[1]] + dt*m_velocities[e1[1]];
                              
               
               update_continuous_broad_phase( e0[0] );
               update_continuous_broad_phase( e0[1] );
               update_continuous_broad_phase( e1[0] );
               update_continuous_broad_phase( e1[1] );
               
               if ( update_collision_candidates.size() < MAX_CANDIDATES )
               {
                  add_point_update_candidates(e0[0], update_collision_candidates);
                  add_point_update_candidates(e0[1], update_collision_candidates);
                  add_point_update_candidates(e1[0], update_collision_candidates);
                  add_point_update_candidates(e1[1], update_collision_candidates);
               }
               else
               {
                  candidate_overflow = true;
               }
               
            }
         }
      }
      
   }

   
   std::cout << "collision candidates remaining: " << update_collision_candidates.size() << std::endl;
   
   return ( !candidate_overflow ) && ( update_collision_candidates.empty() );
   
}



// ---------------------------------------------------------
///
/// Detect all continuous collisions
///
// ---------------------------------------------------------

bool DynamicSurface::detect_collisions( std::vector<Collision>& collisions )
{
   std::cout << "---------------------- detecting collisions ----------------------" << std::endl;
   
   static const unsigned int MAX_COLLISIONS = 5000;
   
   double broad_phase_time = 0;
      
   rebuild_continuous_broad_phase();


   unsigned int num_tri_vertex_potential_collisions = 0;

   for ( unsigned int i = 0; i < m_mesh.tris.size(); ++i )
   {     
      const Vec3ui& tri = m_mesh.tris[i];
      
      if ( tri[0] == tri[1] || tri[1] == tri[2] || tri[2] == tri[0] )    { continue; }

      double broadphase_start = get_time_in_seconds();

      Vec3d low, high;
      triangle_continuous_bounds(i, low, high);
      
      std::vector<unsigned int> potential_collisions;
      
      m_broad_phase->get_potential_vertex_collisions( low, high, potential_collisions );

      broad_phase_time += get_time_in_seconds() - broadphase_start;
      
      num_tri_vertex_potential_collisions += potential_collisions.size();
      
      for ( unsigned int j = 0; j < potential_collisions.size(); ++j )
      {
         unsigned int vertex_index = potential_collisions[j];
         
         assert ( m_mesh.vtxtri[vertex_index].size() != 0 );
      
         if( tri[0] != vertex_index && tri[1] != vertex_index && tri[2] != vertex_index )
         {
            double time, s1, s2, s3, rel_disp;
            Vec3d normal;
            
            Vec3ui sorted_tri = sort_triangle( tri );            
            
            if ( point_triangle_collision( m_positions[vertex_index], m_newpositions[vertex_index],
                                          m_positions[sorted_tri[0]], m_newpositions[sorted_tri[0]],
                                          m_positions[sorted_tri[1]], m_newpositions[sorted_tri[1]],
                                          m_positions[sorted_tri[2]], m_newpositions[sorted_tri[2]],
                                          s1, s2, s3,
                                          normal,
                                          time, rel_disp ) )               
            {
               if ( m_verbose ) 
               { 
                  std::cout << "------- normal: " << normal << std::endl; 
               }
               
               Collision new_collision( false, Vec4ui( vertex_index, sorted_tri[0], sorted_tri[1], sorted_tri[2] ), normal, Vec4d( 1, -s1, -s2, -s3 ), rel_disp );
                              
               if ( m_verbose ) 
               { 
                  std::cout << "collision time: " << time << std::endl; 
               }
               
               collisions.push_back( new_collision );
               
               if ( collisions.size() > MAX_COLLISIONS ) 
               {
                  std::cout << "tri " << i << std::endl;
                  return false; 
               }
            }            
         }
      }
   }
   
   broad_phase_time = 0;
   unsigned int num_edge_edge_potential_collisions = 0;
   
   // edge-edge

   for ( unsigned int edge_index_a = 0; edge_index_a < m_mesh.edges.size(); ++edge_index_a )
   {
      if ( m_mesh.edges[edge_index_a][0] == m_mesh.edges[edge_index_a][1] )    { continue; }
      
      double broadphase_start = get_time_in_seconds();
      
      Vec3d low, high;
      edge_continuous_bounds(edge_index_a, low, high);
      std::vector<unsigned int> potential_collisions;
      m_broad_phase->get_potential_edge_collisions( low, high, potential_collisions );

      broad_phase_time += get_time_in_seconds() - broadphase_start;
      
      num_edge_edge_potential_collisions += potential_collisions.size();
      
      for ( unsigned int j = 0; j < potential_collisions.size(); ++j )
      {
   
         unsigned int edge_index_b = potential_collisions[j];
         
         //if ( edge_index_b <= edge_index_a )    { continue; }
         
         assert ( m_mesh.edges[edge_index_b][0] != m_mesh.edges[edge_index_b][1] );
                  
         Vec2ui e0 = m_mesh.edges[edge_index_a];
         Vec2ui e1 = m_mesh.edges[edge_index_b];
         
         if( e0[0] != e1[0] && e0[0] != e1[1] && e0[1] != e1[0] && e0[1] != e1[1] )
         {            
            
            double time, s0, s2, rel_disp;
            Vec3d normal;
            
            if ( e0[1] < e0[0] ) { swap( e0[0], e0[1] ); }
            if ( e1[1] < e1[0] ) { swap( e1[0], e1[1] ); }
            
            if ( segment_segment_collision( m_positions[e0[0]], m_newpositions[e0[0]],
                                           m_positions[e0[1]], m_newpositions[e0[1]],
                                           m_positions[e1[0]], m_newpositions[e1[0]],
                                           m_positions[e1[1]], m_newpositions[e1[1]],
                                           s0, s2,
                                           normal,
                                           time, rel_disp ) )
            {
                             
               Collision new_collision( true, Vec4ui( e0[0], e0[1], e1[0], e1[1] ), normal, Vec4d( -s0, -(1-s0), s2, (1-s2) ), rel_disp );
                              
               if ( m_verbose ) 
               {
                  std::cout << "collision time: " << time << std::endl;
               }
                              
               collisions.push_back( new_collision );
               
               if ( collisions.size() > MAX_COLLISIONS ) 
               {
                  std::cout << "maxed out collisions at edge " << edge_index_a << std::endl;
                  return false; 
               }               
               
            }
            
         }
      }
   }
   
   return true;
   
}




// ---------------------------------------------------------
///
/// Detect continuous collisions among elements in the given ImpactZones, and adjacent to the given ImpactZones.
///
// ---------------------------------------------------------

void DynamicSurface::detect_new_collisions( const std::vector<ImpactZone> impact_zones, std::vector<Collision>& collisions )
{
   std::cout << "---------------------- detecting new collisions ----------------------" << std::endl;
   
   std::vector<unsigned int> zone_vertices;
   std::vector<unsigned int> zone_edges;
   std::vector<unsigned int> zone_triangles;

   // Get all vertices in the impact zone
   
   for ( unsigned int i = 0; i < impact_zones.size(); ++i )
   {
      for ( unsigned int j = 0; j < impact_zones[i].collisions.size(); ++j )
      {
         add_unique( zone_vertices, impact_zones[i].collisions[j].vertex_indices[0] );
         add_unique( zone_vertices, impact_zones[i].collisions[j].vertex_indices[1] );
         add_unique( zone_vertices, impact_zones[i].collisions[j].vertex_indices[2] );
         add_unique( zone_vertices, impact_zones[i].collisions[j].vertex_indices[3] );         
         
         update_continuous_broad_phase( impact_zones[i].collisions[j].vertex_indices[0] );
         update_continuous_broad_phase( impact_zones[i].collisions[j].vertex_indices[1] );
         update_continuous_broad_phase( impact_zones[i].collisions[j].vertex_indices[2] );
         update_continuous_broad_phase( impact_zones[i].collisions[j].vertex_indices[3] );         
         
      }
   }
   
   // Get all triangles in the impact zone
   
   for ( unsigned int i = 0; i < zone_vertices.size(); ++i )
   {
      for ( unsigned int j = 0; j < m_mesh.vtxtri[zone_vertices[i]].size(); ++j )
      {
         add_unique( zone_triangles, m_mesh.vtxtri[zone_vertices[i]][j] );
      }
   }

   // Get all edges in the impact zone
   
   for ( unsigned int i = 0; i < zone_vertices.size(); ++i )
   {
      for ( unsigned int j = 0; j < m_mesh.vtxedge[zone_vertices[i]].size(); ++j )
      {
         add_unique( zone_edges, m_mesh.vtxedge[zone_vertices[i]][j] );
      }
   }

   // Check zone vertices vs all triangles
   
   for ( unsigned int i = 0; i < zone_vertices.size(); ++i )
   {
      unsigned int vertex_index = zone_vertices[i];

      Vec3d query_low, query_high;
      vertex_continuous_bounds( zone_vertices[i], query_low, query_high );
      std::vector<unsigned int> overlapping_triangles;
      m_broad_phase->get_potential_triangle_collisions( query_low, query_high, overlapping_triangles );
      
      for ( unsigned int j = 0; j < overlapping_triangles.size(); ++j )
      {
         const Vec3ui& tri = m_mesh.tris[overlapping_triangles[j]];
         
         assert( m_mesh.vtxtri[vertex_index].size() != 0 );
         
         if( tri[0] != vertex_index && tri[1] != vertex_index && tri[2] != vertex_index )
         {
            double time, s1, s2, s3, rel_disp;
            Vec3d normal;
            
            Vec3ui sorted_tri = sort_triangle( tri );            
            assert( sorted_tri[0] < sorted_tri[1] && sorted_tri[1] < sorted_tri[2] && sorted_tri[0] < sorted_tri[2] );
            
            if ( point_triangle_collision( m_positions[vertex_index], m_newpositions[vertex_index],
                                          m_positions[sorted_tri[0]], m_newpositions[sorted_tri[0]],
                                          m_positions[sorted_tri[1]], m_newpositions[sorted_tri[1]],
                                          m_positions[sorted_tri[2]], m_newpositions[sorted_tri[2]],
                                          s1, s2, s3,
                                          normal,
                                          time, rel_disp ) )               
            {
                             
               assert( fabs(mag(normal) - 1.0) < 1e-10 );
               
               Collision new_collision( false, Vec4ui( vertex_index, sorted_tri[0], sorted_tri[1], sorted_tri[2] ), normal, Vec4d( 1, -s1, -s2, -s3 ), rel_disp );
               
               add_unique_collision( collisions, new_collision );
               
               
               for ( unsigned int z = 0; z < impact_zones.size(); ++z )
               {
                  for ( unsigned int c = 0; c < impact_zones[z].collisions.size(); ++c )
                  {
                     if ( new_collision.same_vertices( impact_zones[z].collisions[c] ) )
                     {
                        std::cout << "duplicate collision: " << new_collision.vertex_indices << std::endl;
                     }
                  }
               }
               
            } 
         }
      }
   }
   
   // Check zone triangles vs all vertices
   
   for ( unsigned int i = 0; i < zone_triangles.size(); ++i )
   {
      const Vec3ui& tri = m_mesh.tris[zone_triangles[i]];
      
      Vec3d query_low, query_high;
      triangle_continuous_bounds( zone_triangles[i], query_low, query_high );
      std::vector<unsigned int> overlapping_vertices;
      m_broad_phase->get_potential_vertex_collisions( query_low, query_high, overlapping_vertices );
      
      for ( unsigned int j = 0; j < overlapping_vertices.size(); ++j )
      {                      
         unsigned int vertex_index = overlapping_vertices[j];
         
         assert( m_mesh.vtxtri[vertex_index].size() != 0 );
         
         if( tri[0] != vertex_index && tri[1] != vertex_index && tri[2] != vertex_index )
         {
            double time, s1, s2, s3, rel_disp;
            Vec3d normal;
            
            Vec3ui sorted_tri = sort_triangle( tri ); 
            assert( sorted_tri[0] < sorted_tri[1] && sorted_tri[1] < sorted_tri[2] && sorted_tri[0] < sorted_tri[2] );
            
            if ( point_triangle_collision( m_positions[vertex_index], m_newpositions[vertex_index],
                                          m_positions[sorted_tri[0]], m_newpositions[sorted_tri[0]],
                                          m_positions[sorted_tri[1]], m_newpositions[sorted_tri[1]],
                                          m_positions[sorted_tri[2]], m_newpositions[sorted_tri[2]],
                                          s1, s2, s3,
                                          normal,
                                          time, rel_disp ) )                
            {
               
               assert( fabs(mag(normal) - 1.0) < 1e-10 );
               
               Collision new_collision( false, Vec4ui( vertex_index, sorted_tri[0], sorted_tri[1], sorted_tri[2] ), normal, Vec4d( 1, -s1, -s2, -s3 ), rel_disp );                              
               
               add_unique_collision( collisions, new_collision );
               
               
               for ( unsigned int z = 0; z < impact_zones.size(); ++z )
               {
                  for ( unsigned int c = 0; c < impact_zones[z].collisions.size(); ++c )
                  {
                     if ( new_collision.same_vertices( impact_zones[z].collisions[c] ) )
                     {
                        std::cout << "duplicate collision: " << new_collision.vertex_indices << std::endl;
                     }
                  }
               }
               
            } 
         }
      }
   }
   
   // Check zone edges vs all edges
   
   for ( unsigned int i = 0; i < zone_edges.size(); ++i )
   {
      unsigned int edge_index_a = zone_edges[i];
      
      if ( m_mesh.edges[edge_index_a][0] == m_mesh.edges[edge_index_a][1] )    { continue; }
      
      Vec3d low, high;
      edge_continuous_bounds(edge_index_a, low, high);
      std::vector<unsigned int> potential_collisions;
      m_broad_phase->get_potential_edge_collisions( low, high, potential_collisions );
            
      for ( unsigned int j = 0; j < potential_collisions.size(); ++j )
      {   
         unsigned int edge_index_b = potential_collisions[j];
         
         //if ( edge_index_b <= edge_index_a )    { continue; }
         
         assert ( m_mesh.edges[edge_index_b][0] != m_mesh.edges[edge_index_b][1] );    
         
         Vec2ui e0 = m_mesh.edges[edge_index_a];
         Vec2ui e1 = m_mesh.edges[edge_index_b];
         
         if( e0[0] != e1[0] && e0[0] != e1[1] && e0[1] != e1[0] && e0[1] != e1[1] )
         {
            if ( e0[1] < e0[0] ) { swap( e0[0], e0[1] ); }
            if ( e1[1] < e1[0] ) { swap( e1[0], e1[1] ); }
            
            assert( e0[0] < e0[1] && e1[0] < e1[1] );
            
            double time, s0, s2, rel_disp;
            Vec3d normal;
            if ( segment_segment_collision( m_positions[e0[0]], m_newpositions[e0[0]],
                                           m_positions[e0[1]], m_newpositions[e0[1]],
                                           m_positions[e1[0]], m_newpositions[e1[0]],
                                           m_positions[e1[1]], m_newpositions[e1[1]],
                                           s0, s2,
                                           normal,
                                           time, rel_disp ) )
            {
               
               double relvel = dot(normal, s0*m_velocities[e0[0]] + (1.0-s0)*m_velocities[e0[1]] - (s2*m_velocities[e1[0]] + (1.0-s2)*m_velocities[e1[1]]));
               
               std::cout << "relative velocity: " << relvel << std::endl;
               
               normalize(normal);
               
               Collision new_collision( true, Vec4ui( e0[0], e0[1], e1[0], e1[1] ), normal, Vec4d( -s0, -(1-s0), s2, (1-s2) ), rel_disp );
               
               add_unique_collision( collisions, new_collision );
               
               
               for ( unsigned int z = 0; z < impact_zones.size(); ++z )
               {
                  for ( unsigned int c = 0; c < impact_zones[z].collisions.size(); ++c )
                  {
                     if ( new_collision.same_vertices( impact_zones[z].collisions[c] ) )
                     {
                        std::cout << "duplicate collision: " << new_collision.vertex_indices << std::endl;
                     }
                  }
               }

            }
         }
      }
   }
}




// ---------------------------------------------------------
///
/// Combine impact zones which have overlapping vertex stencils
///
// ---------------------------------------------------------

void DynamicSurface::merge_impact_zones( std::vector<ImpactZone>& new_impact_zones, std::vector<ImpactZone>& master_impact_zones )
{
   std::cout << " merging impact zones " << std::endl;
   
   bool merge_ocurred = true;
      
   for ( unsigned int i = 0; i < master_impact_zones.size(); ++i )
   {
      master_impact_zones[i].all_solved = true;
   }

   for ( unsigned int i = 0; i < new_impact_zones.size(); ++i )
   {
      new_impact_zones[i].all_solved = false;
   }

   
   while ( merge_ocurred )
   {
            
      merge_ocurred = false;
           
      for ( unsigned int i = 0; i < new_impact_zones.size(); ++i )
      {
         bool i_is_disjoint = true;
         
         for ( unsigned int j = 0; j < master_impact_zones.size(); ++j )
         {
            if ( master_impact_zones[j].share_vertices( new_impact_zones[i] ) )
            {
               
               master_impact_zones[j].all_solved &= new_impact_zones[i].all_solved;
               
               // steal all of i's collisions
               for ( unsigned int c = 0; c < new_impact_zones[i].collisions.size(); ++c )
               {

                  bool same_collision_exists = false;
                  
                  for ( unsigned int m = 0; m < master_impact_zones[j].collisions.size(); ++m )
                  {                 
                     if ( master_impact_zones[j].collisions[m].same_vertices( new_impact_zones[i].collisions[c] ) )
                     {

                        same_collision_exists = true;
                        break;
                     }
                     
                  }
                  
                  
                  master_impact_zones[j].collisions.push_back( new_impact_zones[i].collisions[c] );
                  
               }
               
               i_is_disjoint = false;
               merge_ocurred = true;
               break;
            }
         }     // end for(j)
         
         if ( i_is_disjoint )
         {
            // copy the impact zone
            
            ImpactZone new_zone;
            for ( unsigned int c = 0; c < new_impact_zones[i].collisions.size(); ++c )
            {
               new_zone.collisions.push_back( new_impact_zones[i].collisions[c] );
            }
            
            new_zone.all_solved = new_impact_zones[i].all_solved;
            
            master_impact_zones.push_back( new_zone );
         }
      }     // end for(i)
      
      new_impact_zones = master_impact_zones;
      master_impact_zones.clear();
      
   }  // while

   master_impact_zones = new_impact_zones;
     
}


// ---------------------------------------------------------
///
/// Iteratively project out relative normal velocities for a set of collisions in an impact zone until all collisions are solved.
///
// ---------------------------------------------------------

bool DynamicSurface::iterated_inelastic_projection( ImpactZone& iz, double dt )
{
   assert( m_masses.size() == m_positions.size() );
   
   static const unsigned int MAX_PROJECTION_ITERATIONS = 10;
   
   for ( unsigned int i = 0; i < MAX_PROJECTION_ITERATIONS; ++i )
   {
      std::cout << "number of collisions in zone: " << iz.collisions.size() << std::endl;
      
      m_verbose = true;
      inelastic_projection( iz );
      m_verbose = false;
            
      bool collision_still_exists = false;
      
      for ( unsigned int c = 0; c < iz.collisions.size(); ++c )
      {
         // run collision detection on this pair again
         
         Collision& collision = iz.collisions[c];
         const Vec4ui& vs = collision.vertex_indices;
            
         m_newpositions[vs[0]] = m_positions[vs[0]] + dt * m_velocities[vs[0]];
         m_newpositions[vs[1]] = m_positions[vs[1]] + dt * m_velocities[vs[1]];
         m_newpositions[vs[2]] = m_positions[vs[2]] + dt * m_velocities[vs[2]];
         m_newpositions[vs[3]] = m_positions[vs[3]] + dt * m_velocities[vs[3]];
            
         std::cout << "checking collision " << vs << std::endl;
         
         if ( collision.is_edge_edge )
         {
            
            double time, s0, s2, rel_disp;
            Vec3d normal;
            
            assert( vs[0] < vs[1] && vs[2] < vs[3] );       // should have been sorted by original collision detection
            
            if ( segment_segment_collision( m_positions[vs[0]], m_newpositions[vs[0]],
                                            m_positions[vs[1]], m_newpositions[vs[1]],
                                            m_positions[vs[2]], m_newpositions[vs[2]],
                                            m_positions[vs[3]], m_newpositions[vs[3]],
                                            s0, s2,
                                            normal,
                                            time, rel_disp ) )
               
            {
               std::cout << "collision remains.  delta alphas: " << Vec4d( -s0, -(1-s0), s2, (1-s2) ) - collision.alphas << std::endl;
               
               collision.normal = normal;
               collision.alphas = Vec4d( -s0, -(1-s0), s2, (1-s2) );
               collision.relative_displacement = rel_disp;
               collision_still_exists = true;
            }
            
         }
         else
         {
               
            double time, s1, s2, s3, rel_disp;
            Vec3d normal;
            
            assert( vs[1] < vs[2] && vs[2] < vs[3] && vs[1] < vs[3] );    // should have been sorted by original collision detection
            
            if ( point_triangle_collision( m_positions[vs[0]], m_newpositions[vs[0]],
                                           m_positions[vs[1]], m_newpositions[vs[1]],
                                           m_positions[vs[2]], m_newpositions[vs[2]],
                                           m_positions[vs[3]], m_newpositions[vs[3]],
                                           s1, s2, s3,
                                           normal,
                                           time, rel_disp ) )                  
            {
               std::cout << "collision remains.  delta alphas: " << Vec4d( 1, -s1, -s2, -s3 ) - collision.alphas << std::endl;
               
               collision.normal = normal;
               collision.alphas = Vec4d( 1, -s1, -s2, -s3 );
               collision.relative_displacement = rel_disp;
               collision_still_exists = true;
            }
            
         }
         
      } // for collisions
      
      if ( false == collision_still_exists )  
      {
         std::cout << "no collision remains for this zone" << std::endl;
         return true; 
      }
      
   } // for iterations
 
   std::cout << "reached max iterations for this zone" << std::endl;
   return true;
   
}


// ---------------------------------------------------------
///
/// Project out relative normal velocities for a set of collisions in an impact zone.
///
// ---------------------------------------------------------

bool DynamicSurface::inelastic_projection( const ImpactZone& iz )
{
   
   std::cout << " ----- using sparse solver " << std::endl;
   
   static double IMPULSE_MULTIPLIER = 0.8;
   
   const unsigned int k = iz.collisions.size();    // notation from [Harmon et al 2008]: k == number of collisions
   
   std::vector<unsigned int> zone_vertices;
   iz.get_all_vertices( zone_vertices );
   
   const unsigned int n = zone_vertices.size();       // n == number of distinct colliding vertices
   
   if ( m_verbose )
   {
      std::cout << "GCT: " << 3*n << "x" << k << std::endl;
   }
   
   SparseMatrixDynamicCSR GCT( 3*n, k );
   GCT.set_zero();
   
   // construct matrix grad C transpose
   for ( unsigned int i = 0; i < k; ++i )
   {
      // set col i
      const Collision& coll = iz.collisions[i];
      
      for ( unsigned int v = 0; v < 4; ++v )
      {
         // block row j ( == block column j of grad C )
         unsigned int j = coll.vertex_indices[v];
         
         std::vector<unsigned int>::iterator zone_vertex_iter = find( zone_vertices.begin(), zone_vertices.end(), j );
         
         assert( zone_vertex_iter != zone_vertices.end() );
         
         unsigned int mat_j = (unsigned int) ( zone_vertex_iter - zone_vertices.begin() );
         
         GCT(mat_j*3, i) = coll.alphas[v] * coll.normal[0];
         GCT(mat_j*3+1, i) = coll.alphas[v] * coll.normal[1];
         GCT(mat_j*3+2, i) = coll.alphas[v] * coll.normal[2];
         
      }
   }

   Array1d inv_masses;
   inv_masses.reserve(3*n);
   Array1d column_velocities;
   column_velocities.reserve(3*n);
   
   for ( unsigned int i = 0; i < n; ++i )
   {
      if ( m_masses[zone_vertices[i]] < 100.0 )
      {
         inv_masses.push_back( 1.0 / m_masses[zone_vertices[i]] );
         inv_masses.push_back( 1.0 / m_masses[zone_vertices[i]] );
         inv_masses.push_back( 1.0 / m_masses[zone_vertices[i]] );
      }
      else
      {
         // infinite mass (scripted objects)
         
         inv_masses.push_back( 0.0 );
         inv_masses.push_back( 0.0 );
         inv_masses.push_back( 0.0 );         
      }

      column_velocities.push_back( m_velocities[zone_vertices[i]][0] );
      column_velocities.push_back( m_velocities[zone_vertices[i]][1] );
      column_velocities.push_back( m_velocities[zone_vertices[i]][2] );
   }

   //
   // minimize | M^(-1/2) * GC^T x - M^(1/2) * v |^2
   //
   
   // solution vector
   Array1d x(k);
         
   static const bool use_cgnr = false;
   KrylovSolverStatus solver_result;
   
   if ( use_cgnr )
   {
      std::cout << "CGNR currently disabled: matrices are not scaled by masses." << std::endl;
      assert( false );
      
      CGNR_Solver cg_solver;
      SparseMatrixStaticCSR solver_matrix( GCT );
      cg_solver.max_iterations = INT_MAX;
      solver_result = cg_solver.solve( solver_matrix, column_velocities.data, x.data );      
   }
   else
   {
      // normal equations: GC * M^(-1) GCT * x = GC * v
      //                   A * x = b

      SparseMatrixDynamicCSR A( k, k );
      A.set_zero();
      AtDB( GCT, inv_masses.data, GCT, A ); 
      
      Array1d b(k);
      GCT.apply_transpose( column_velocities.data, b.data );   

      if ( m_verbose )  { std::cout << "system built" << std::endl; }

      MINRES_CR_Solver solver;   
      SparseMatrixStaticCSR solver_matrix( A );    // convert dynamic to static
      solver.max_iterations = INT_MAX;
      solver_result = solver.solve( solver_matrix, b.data, x.data ); 
   }

   if ( solver_result != KRYLOV_CONVERGED )
   {
      std::cout << "CR solver failed: ";
      
      if ( solver_result == KRYLOV_BREAKDOWN )
      {
         std::cout << "KRYLOV_BREAKDOWN" << std::endl;
      }
      else
      {
         std::cout << "KRYLOV_EXCEEDED_MAX_ITERATIONS" << std::endl;
      }
      
      assert( false );
      
      return false;          
   } 
   
   std::cout << "solved" << std::endl;
   
   // apply impulses 
   Array1d applied_impulses(3*n);
   GCT.apply( x.data, applied_impulses.data );
     
   for ( unsigned int i = 0; i < applied_impulses.size(); ++i )
   {
      column_velocities[i] -= IMPULSE_MULTIPLIER * inv_masses[i] * applied_impulses[i];
   }
   
   for ( unsigned int i = 0; i < n; ++i )
   {
      Vec3d new_velocity( column_velocities[3*i], column_velocities[3*i + 1], column_velocities[3*i + 2] );
      
      m_velocities[zone_vertices[i]][0] = column_velocities[3*i];
      m_velocities[zone_vertices[i]][1] = column_velocities[3*i + 1];
      m_velocities[zone_vertices[i]][2] = column_velocities[3*i + 2];      
   }
    
   
   return true;
   
}


// ---------------------------------------------------------
///
/// Handle all collisions simultaneously by iteratively solving individual impact zones until no new collisions are detected.
///
// ---------------------------------------------------------

bool DynamicSurface::handle_collisions_simultaneous(double dt)
{
   std::cout << "---------------------- handling simultaneous collisions ----------------------" << std::endl;

   // copy
   std::vector<Vec3d> old_velocities = m_velocities;

   std::vector<ImpactZone> impact_zones;

   bool finished_detecting_collisions = false;
   
   std::vector<Collision> total_collisions;
   finished_detecting_collisions = detect_collisions(total_collisions);
   
   std::cout << total_collisions.size() << " collisions detected " << std::endl;
   
   while ( false == total_collisions.empty() )
   {      
      // insert each new collision constraint into its own impact zone
      std::vector<ImpactZone> new_impact_zones;
      for ( unsigned int i = 0; i < total_collisions.size(); ++i )
      {
         ImpactZone new_zone;
         new_zone.collisions.push_back( total_collisions[i] );
         new_impact_zones.push_back( new_zone );
      }
      
      assert( new_impact_zones.size() == total_collisions.size() );

      // merge all impact zones that share vertices
      merge_impact_zones( new_impact_zones, impact_zones );

      for ( int i = 0; i < (int) impact_zones.size(); ++i )
      {
         if ( impact_zones[i].all_solved ) 
         {
            impact_zones.erase( impact_zones.begin() + i );
            --i;
         }
      }

      unsigned int total_num_collisions = 0;
      for ( int i = 0; i < (int) impact_zones.size(); ++i )
      {
         assert( false == impact_zones[i].all_solved );
         total_num_collisions += impact_zones[i].collisions.size();
      }            
      
      std::cout << impact_zones.size() << " impact zones built" << std::endl;
      
      std::cout << "---------------------- solving ----------------------" << std::endl;
      
      // for each impact zone
      for ( unsigned int i = 0; i < impact_zones.size(); ++i )
      {
         
         std::vector<unsigned int> zone_vertices;
         
         // reset impact zone to pre-response m_velocities
         for ( unsigned int j = 0; j < impact_zones[i].collisions.size(); ++j )
         {
            Vec4ui& vs = impact_zones[i].collisions[j].vertex_indices;
            
            m_velocities[vs[0]] = old_velocities[vs[0]];
            m_velocities[vs[1]] = old_velocities[vs[1]];
            m_velocities[vs[2]] = old_velocities[vs[2]];
            m_velocities[vs[3]] = old_velocities[vs[3]]; 
            
            zone_vertices.push_back( vs[0] );
            zone_vertices.push_back( vs[1] );
            zone_vertices.push_back( vs[2] );
            zone_vertices.push_back( vs[3] );            
         }
         
         // apply inelastic projection
         
         bool solver_ok = iterated_inelastic_projection( impact_zones[i], dt );
         
         if ( false == solver_ok )
         {
            std::cout << "solver problem, cutting dt" << std::endl;
            return false;
         }
         
         // reset predicted m_positions
         for ( unsigned int j = 0; j < impact_zones[i].collisions.size(); ++j )
         {
            const Vec4ui& vs = impact_zones[i].collisions[j].vertex_indices;            

            m_newpositions[vs[0]] = m_positions[vs[0]] + dt * m_velocities[vs[0]];
            m_newpositions[vs[1]] = m_positions[vs[1]] + dt * m_velocities[vs[1]];
            m_newpositions[vs[2]] = m_positions[vs[2]] + dt * m_velocities[vs[2]];
            m_newpositions[vs[3]] = m_positions[vs[3]] + dt * m_velocities[vs[3]];
         } 
      
      }  // for IZs
      
      total_collisions.clear();
      
      if ( !finished_detecting_collisions )
      {
         std::cout << "attempting to finish global collision detection" << std::endl;
         finished_detecting_collisions = detect_collisions( total_collisions );
         impact_zones.clear();
      }
      else
      {
         detect_new_collisions( impact_zones, total_collisions );
      }
   
      std::cout << total_collisions.size() << " new collisions detected " << std::endl;
   }
   
   return true;
}


// ---------------------------------------------------------
///
/// Advance mesh by one time step 
///
// ---------------------------------------------------------

extern bool g_skip_to_impact_zones;

void DynamicSurface::integrate( double dt )
{     
      
   assert( m_positions.size() == m_velocities.size() );
  
   // Handle proximities

   if ( m_collision_safety )
   {
      m_broad_phase->update_broad_phase_static( *this );            
      handle_edge_edge_proximities( dt );
      handle_triangle_point_proximities( dt );
   }

   
   // Set predicted m_positions
   for(unsigned int i = 0; i < m_positions.size(); i++)
   {
      m_newpositions[i] = m_positions[i] + dt * m_velocities[i];
   }
   
   if ( m_collision_safety )
   {        
      // Handle continuous collisions
      rebuild_continuous_broad_phase();

      bool all_collisions_handled = false;

      if ( false == g_skip_to_impact_zones )
      {
         handle_point_vs_solid_triangle_collisions( dt );
         all_collisions_handled = handle_collisions( dt );
      }
      
      // failsafe impact zones
      
      if ( !all_collisions_handled )
      {
         handle_collisions_simultaneous(dt);            
      }
   
      //assert_predicted_mesh_is_intersection_free();
      
   }

   // Set m_positions
   for(unsigned int i = 0; i < m_positions.size(); i++)
   {
      m_positions[i] = m_newpositions[i];
   } 
      
      
}

// ---------------------------------------------------------
///
/// Construct static acceleration structure
///
// ---------------------------------------------------------

void DynamicSurface::rebuild_static_broad_phase()
{
   if ( m_collision_safety )
   {
      m_broad_phase->update_broad_phase_static( *this );
   }
}

// ---------------------------------------------------------
///
/// Construct continuous acceleration structure
///
// ---------------------------------------------------------

void DynamicSurface::rebuild_continuous_broad_phase()
{
   if ( m_collision_safety )
   {
      m_broad_phase->update_broad_phase_continuous( *this );
   }
}


// ---------------------------------------------------------
///
/// Update the broadphase elements incident to the given vertex
///
// ---------------------------------------------------------

void DynamicSurface::update_static_broad_phase( unsigned int vertex_index )
{
   const std::vector<unsigned int>& incident_tris = m_mesh.vtxtri[ vertex_index ];
   const std::vector<unsigned int>& incident_edges = m_mesh.vtxedge[ vertex_index ];
   
   Vec3d low, high;
   vertex_static_bounds( vertex_index, low, high );
   m_broad_phase->update_vertex( vertex_index, low, high );
   
   for ( unsigned int t = 0; t < incident_tris.size(); ++t )
   {
      triangle_static_bounds( incident_tris[t], low, high );
      m_broad_phase->update_triangle( incident_tris[t], low, high );
   }
   
   for ( unsigned int e = 0; e < incident_edges.size(); ++e )
   {
      edge_static_bounds( incident_edges[e], low, high );
      m_broad_phase->update_edge( incident_edges[e], low, high );
   }

}


// ---------------------------------------------------------
///
/// Update the broadphase elements incident to the given vertex, using current and predicted vertex positions
///
// ---------------------------------------------------------

void DynamicSurface::update_continuous_broad_phase( unsigned int vertex_index )
{
   const std::vector<unsigned int>& incident_tris = m_mesh.vtxtri[ vertex_index ];
   const std::vector<unsigned int>& incident_edges = m_mesh.vtxedge[ vertex_index ];

   Vec3d low, high;
   vertex_continuous_bounds( vertex_index, low, high );
   m_broad_phase->update_vertex( vertex_index, low, high );
   
   for ( unsigned int t = 0; t < incident_tris.size(); ++t )
   {
      triangle_continuous_bounds( incident_tris[t], low, high );
      m_broad_phase->update_triangle( incident_tris[t], low, high );
   }
   
   for ( unsigned int e = 0; e < incident_edges.size(); ++e )
   {
      edge_continuous_bounds( incident_edges[e], low, high );
      m_broad_phase->update_edge( incident_edges[e], low, high );
   }
}


// ---------------------------------------------------------
///
/// Compute the (padded) AABB of a vertex
///
// ---------------------------------------------------------

void DynamicSurface::vertex_static_bounds(unsigned int v, Vec3d &xmin, Vec3d &xmax) const
{
   if ( m_mesh.vtxtri[v].size() == 0 )
   {
      xmin = Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax = -Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
   else
   {
      xmin = m_positions[v] - Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax = m_positions[v] + Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
}

// ---------------------------------------------------------
///
/// Compute the AABB of an edge
///
// ---------------------------------------------------------

void DynamicSurface::edge_static_bounds(unsigned int e, Vec3d &xmin, Vec3d &xmax) const
{
   const Vec2ui& edge = m_mesh.edges[e];
   if ( edge[0] == edge[1] )
   {
      xmin = Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax = -Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
   else
   {            
      minmax(m_positions[edge[0]], m_positions[edge[1]], xmin, xmax);
      xmin -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
}

// ---------------------------------------------------------
///
/// Compute the AABB of a triangle
///
// ---------------------------------------------------------

void DynamicSurface::triangle_static_bounds(unsigned int t, Vec3d &xmin, Vec3d &xmax) const
{
   const Vec3ui& tri = m_mesh.tris[t];  
   if ( tri[0] == tri[1] )
   {
      xmin = Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax = -Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
   else
   {      
      minmax(m_positions[tri[0]], m_positions[tri[1]], m_positions[tri[2]], xmin, xmax);
      xmin -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
}

// ---------------------------------------------------------
///
/// Compute the AABB of a continuous vertex
///
// ---------------------------------------------------------

void DynamicSurface::vertex_continuous_bounds(unsigned int v, Vec3d &xmin, Vec3d &xmax) const
{
   if ( m_mesh.vtxtri[v].size() == 0 )
   {
      xmin = Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax = -Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
   else
   {
      minmax(m_positions[v], m_newpositions[v], xmin, xmax);
      xmin -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
}

// ---------------------------------------------------------
///
/// Compute the AABB of a continuous edge
///
// ---------------------------------------------------------

void DynamicSurface::edge_continuous_bounds(unsigned int e, Vec3d &xmin, Vec3d &xmax) const
{
   const Vec2ui& edge = m_mesh.edges[e];   
   if ( edge[0] == edge[1] )
   {
      xmin = Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax = -Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
   else
   {      
      minmax(m_positions[edge[0]], m_newpositions[edge[0]], m_positions[edge[1]], m_newpositions[edge[1]], xmin, xmax);
      xmin -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);   
   }
}

// ---------------------------------------------------------
///
/// Compute the AABB of a continuous triangle
///
// ---------------------------------------------------------

void DynamicSurface::triangle_continuous_bounds(unsigned int t, Vec3d &xmin, Vec3d &xmax) const
{
   const Vec3ui& tri = m_mesh.tris[t];
   if ( tri[0] == tri[1] )
   {
      xmin = Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax = -Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   }
   else
   {
      minmax(m_positions[tri[0]], m_newpositions[tri[0]], m_positions[tri[1]], m_newpositions[tri[1]], m_positions[tri[2]], m_newpositions[tri[2]], xmin, xmax);
      xmin -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
      xmax += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);   
   }
}


// --------------------------------------------------------
///
/// Check a triangle (by index) vs all other triangles for any kind of intersection
///
// --------------------------------------------------------

bool DynamicSurface::check_triangle_vs_all_triangles_for_intersection( unsigned int tri_index  )
{
   return check_triangle_vs_all_triangles_for_intersection( m_mesh.tris[tri_index] );
}

// --------------------------------------------------------
///
/// Check a triangle vs all other triangles for any kind of intersection
///
// --------------------------------------------------------

bool DynamicSurface::check_triangle_vs_all_triangles_for_intersection( const Vec3ui& tri )
{
   bool any_intersection = false;
   
   std::vector<unsigned int> overlapping_triangles;
   Vec3d low, high;
   
   minmax( m_positions[tri[0]], m_positions[tri[1]], low, high );
   low -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   high += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   
   m_broad_phase->get_potential_triangle_collisions( low, high, overlapping_triangles );
   
   for ( unsigned int i = 0; i < overlapping_triangles.size(); ++i )
   {
      
      bool result = check_edge_triangle_intersection_by_index( tri[0], tri[1],
                                                              m_mesh.tris[overlapping_triangles[i]][0], 
                                                              m_mesh.tris[overlapping_triangles[i]][1], 
                                                              m_mesh.tris[overlapping_triangles[i]][2],
                                                              m_positions,
                                                              false );
      
      if ( result )
      {
         check_edge_triangle_intersection_by_index( tri[0], tri[1],
                                                   m_mesh.tris[overlapping_triangles[i]][0], 
                                                   m_mesh.tris[overlapping_triangles[i]][1], 
                                                   m_mesh.tris[overlapping_triangles[i]][2],
                                                   m_positions,
                                                   true );
         
         std::cout << "intersection: " << tri[0] << "  " << tri[1] << " vs " << m_mesh.tris[overlapping_triangles[i]] << std::endl;
         
         any_intersection = true;
      }
   }
   
   minmax( m_positions[tri[1]], m_positions[tri[2]], low, high );
   low -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   high += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   
   overlapping_triangles.clear();
   m_broad_phase->get_potential_triangle_collisions( low, high, overlapping_triangles );
   
   for ( unsigned int i = 0; i < overlapping_triangles.size(); ++i )
   {
      
      bool result = check_edge_triangle_intersection_by_index( tri[1], tri[2],
                                                              m_mesh.tris[overlapping_triangles[i]][0], 
                                                              m_mesh.tris[overlapping_triangles[i]][1], 
                                                              m_mesh.tris[overlapping_triangles[i]][2],
                                                              m_positions,
                                                              false );
      
      if ( result )
      {
         check_edge_triangle_intersection_by_index( tri[1], tri[2],
                                                   m_mesh.tris[overlapping_triangles[i]][0], 
                                                   m_mesh.tris[overlapping_triangles[i]][1], 
                                                   m_mesh.tris[overlapping_triangles[i]][2],
                                                   m_positions,
                                                   true );
         
         std::cout << "intersection: " << tri[1] << "  " << tri[2] << " vs " << m_mesh.tris[overlapping_triangles[i]] << std::endl;
         any_intersection = true;
      }
   }
   
   minmax( m_positions[tri[2]], m_positions[tri[0]], low, high );
   low -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   high += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   
   overlapping_triangles.clear();
   m_broad_phase->get_potential_triangle_collisions( low, high, overlapping_triangles );
   
   for ( unsigned int i = 0; i < overlapping_triangles.size(); ++i )
   {
      
      bool result = check_edge_triangle_intersection_by_index( tri[2], tri[0],
                                                              m_mesh.tris[overlapping_triangles[i]][0], 
                                                              m_mesh.tris[overlapping_triangles[i]][1], 
                                                              m_mesh.tris[overlapping_triangles[i]][2],
                                                              m_positions,
                                                              false );
      
      if ( result )
      {
         check_edge_triangle_intersection_by_index( tri[2], tri[0],
                                                   m_mesh.tris[overlapping_triangles[i]][0], 
                                                   m_mesh.tris[overlapping_triangles[i]][1], 
                                                   m_mesh.tris[overlapping_triangles[i]][2],
                                                   m_positions,
                                                   true );
         
         std::cout << "intersection: " << tri[2] << "  " << tri[0] << " vs " << m_mesh.tris[overlapping_triangles[i]] << std::endl;
         any_intersection = true;         
      }
   }
   
   //
   // edges
   //
   
   minmax( m_positions[tri[0]], m_positions[tri[1]], m_positions[tri[2]], low, high );
   low -= Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   high += Vec3d(m_proximity_epsilon, m_proximity_epsilon, m_proximity_epsilon);
   
   std::vector<unsigned int> overlapping_edges;
   m_broad_phase->get_potential_edge_collisions( low, high, overlapping_edges );
   
   for ( unsigned int i = 0; i < overlapping_edges.size(); ++i )
   {
      
      bool result = check_edge_triangle_intersection_by_index( m_mesh.edges[overlapping_edges[i]][0], m_mesh.edges[overlapping_edges[i]][1], 
                                                              tri[0], tri[1], tri[2],
                                                              m_positions,
                                                              false );
      
      if ( result )
      {
         check_edge_triangle_intersection_by_index( m_mesh.edges[overlapping_edges[i]][0], m_mesh.edges[overlapping_edges[i]][1], 
                                                   tri[0], tri[1], tri[2],
                                                   m_positions,
                                                   true );
         
         std::cout << "intersection: " << m_mesh.edges[overlapping_edges[i]] << " vs " << m_mesh.tris[i] << std::endl;
         any_intersection = true;         
      }
   }
   
   return any_intersection;
}


// ---------------------------------------------------------
///
/// Fire an assert if any edge is intersecting any triangles
///
// ---------------------------------------------------------

void DynamicSurface::assert_mesh_is_intersection_free( )
{
   std::cout << "checking intersections" << std::endl;
      
   g_intersecting_triangles.clear();
   
   m_broad_phase->update_broad_phase_static( *this );
      
   for ( unsigned int i = 0; i < m_mesh.tris.size(); ++i )
   {
      std::vector<unsigned int> edge_candidates;
      
      Vec3d low, high;
      triangle_static_bounds( i, low, high );       
      m_broad_phase->get_potential_edge_collisions( low, high, edge_candidates );
         
      const Vec3ui& triangle_a = m_mesh.tris[i];
      
      if ( triangle_a[0] == triangle_a[1] || triangle_a[1] == triangle_a[2] || triangle_a[2] == triangle_a[0] )    { continue; }
      
      assert( m_mesh.get_edge( triangle_a[0], triangle_a[1] ) != m_mesh.edges.size() );
      assert( m_mesh.get_edge( triangle_a[1], triangle_a[2] ) != m_mesh.edges.size() );
      assert( m_mesh.get_edge( triangle_a[2], triangle_a[0] ) != m_mesh.edges.size() );
      
      for ( unsigned int j = 0; j < edge_candidates.size(); ++j )
      {
         
         const Vec2ui& edge_b = m_mesh.edges[ edge_candidates[j] ];
         
         if ( edge_b[0] == edge_b[1] )    { continue; }
         
         if (    edge_b[0] == triangle_a[0] || edge_b[0] == triangle_a[1] || edge_b[0] == triangle_a[2] 
              || edge_b[1] == triangle_a[0] || edge_b[1] == triangle_a[1] || edge_b[1] == triangle_a[2] )
         {
            continue;
         }
         
         if ( segment_triangle_intersection( m_positions[edge_b[0]], m_positions[edge_b[1]], 
                                             m_positions[triangle_a[0]], m_positions[triangle_a[1]], m_positions[triangle_a[2]], 
                                             false, m_verbose ) )
         {   
            
            if ( m_collision_safety )
            {
               std::cout << "Intersection!  Triangle " << triangle_a << " vs edge " << edge_b << std::endl;
               
               segment_triangle_intersection( m_positions[edge_b[0]], m_positions[edge_b[1]], 
                                              m_positions[triangle_a[0]], m_positions[triangle_a[1]], m_positions[triangle_a[2]], true );
               
               assert(0);
            }
            
            g_intersecting_triangles.push_back( i );
            
         }
      }
   }
    
   std::vector<unsigned int>::iterator new_end = std::unique( g_intersecting_triangles.begin(), g_intersecting_triangles.end() );
   g_intersecting_triangles.erase( new_end, g_intersecting_triangles.end() );
}

// ---------------------------------------------------------
///
/// Using m_newpositions as the geometry, fire an assert if any edge is intersecting any triangles
///
// ---------------------------------------------------------

void DynamicSurface::assert_predicted_mesh_is_intersection_free( )
{
   std::cout << "checking intersections at end time" << std::endl;
      
   rebuild_continuous_broad_phase();
   
   for ( unsigned int i = 0; i < m_mesh.tris.size(); ++i )
   {
      std::vector<unsigned int> edge_candidates;
      
      Vec3d low, high;
      triangle_continuous_bounds( i, low, high );       
      m_broad_phase->get_potential_edge_collisions( low, high, edge_candidates );
      
      const Vec3ui& triangle_a = m_mesh.tris[i];
      
      if ( triangle_a[0] == triangle_a[1] || triangle_a[1] == triangle_a[2] || triangle_a[2] == triangle_a[0] )    { continue; }
      
      for ( unsigned int j = 0; j < edge_candidates.size(); ++j )
      {
         
         const Vec2ui& edge_b = m_mesh.edges[ edge_candidates[j] ];
         
         if ( edge_b[0] == edge_b[1] )    { continue; }
         
         if ( check_edge_triangle_intersection_by_index( edge_b[0], edge_b[1], 
                                                         triangle_a[0], triangle_a[1], triangle_a[2], 
                                                         m_newpositions, m_verbose )  )
         {
            if ( m_collision_safety )
            {
               std::cout << "Intersection!  Triangle " << triangle_a << " vs edge " << edge_b << std::endl;
            }
                        
            m_verbose = true;
                        
            std::cout << "-----\n edge-triangle check using m_positions" << std::endl;
            
            check_edge_triangle_intersection_by_index( edge_b[0], edge_b[1], 
                                                       triangle_a[0], triangle_a[1], triangle_a[2], 
                                                       m_positions, m_verbose );
            
            std::cout << "-----\n edge-triangle check using new m_positions" << std::endl;
            
            check_edge_triangle_intersection_by_index( edge_b[0], edge_b[1], 
                                                       triangle_a[0], triangle_a[1], triangle_a[2], 
                                                       m_newpositions, m_verbose );
            
            const Vec3d& ea = m_positions[edge_b[0]];
            const Vec3d& eb = m_positions[edge_b[1]];
            const Vec3d& ta = m_positions[triangle_a[0]];
            const Vec3d& tb = m_positions[triangle_a[1]];
            const Vec3d& tc = m_positions[triangle_a[2]];
            
            const Vec3d& ea_new = m_newpositions[edge_b[0]];
            const Vec3d& eb_new = m_newpositions[edge_b[1]];
            const Vec3d& ta_new = m_newpositions[triangle_a[0]];
            const Vec3d& tb_new = m_newpositions[triangle_a[1]];
            const Vec3d& tc_new = m_newpositions[triangle_a[2]];
            
            std::cout << ea << std::endl;
            std::cout << eb << std::endl;
            std::cout << ta << std::endl;
            std::cout << tb << std::endl;
            std::cout << tc << std::endl;
            
            std::cout << ea_new << std::endl;
            std::cout << eb_new << std::endl;
            std::cout << ta_new << std::endl;
            std::cout << tb_new << std::endl;
            std::cout << tc_new << std::endl;
            
            std::vector<double> possible_times;

            Vec3d normal;
            
            std::cout << "-----" << std::endl;
            
            assert( !segment_segment_collision( ea, ea_new, eb, eb_new, ta, ta_new, tb, tb_new ) );
            
            std::cout << "-----" << std::endl;
            
            assert( !segment_segment_collision( ea, ea_new, eb, eb_new, tb, tb_new, tc, tc_new ) );
                        
            std::cout << "-----" << std::endl;
            
            assert( !segment_segment_collision( ea, ea_new, eb, eb_new, tc, tc_new, ta, ta_new ) );
            
            std::cout << "-----" << std::endl;
            
            assert( !point_triangle_collision( ea, ea_new, ta, ta_new, tb, tb_new, tc, tc_new ) );
            
            std::cout << "-----" << std::endl;

            assert( !point_triangle_collision( eb, eb_new, ta, ta_new, tb, tb_new, tc, tc_new ) );
                                   
            m_verbose = false;
            
            if ( m_collision_safety )
            {
               assert(0);
            }
         }
      }
   }
   
}


