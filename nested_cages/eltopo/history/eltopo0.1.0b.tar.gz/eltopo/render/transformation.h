#ifndef TRANSFORMATION_H
#define TRANSFORMATION_H

// Here we define a class to hold 4x4 transformation matrices.
// There are separate members to apply these to points or directions,
// taking care of the homogeneous fourth coordinate appropriately.

#include "vec.h"

struct Transformation
{
   float M[4][4];

   Transformation(void)
   {
      M[0][0]=1; M[0][1]=0; M[0][2]=0; M[0][3]=0;
      M[1][0]=0; M[1][1]=1; M[1][2]=0; M[1][3]=0;
      M[2][0]=0; M[2][1]=0; M[2][2]=1; M[2][3]=0;
      M[3][0]=0; M[3][1]=0; M[3][2]=0; M[3][3]=1;
   }

   Vec3f apply_to_point(const Vec3f& x) const
   {
      float w=M[3][0]*x[0] + M[3][1]*x[1] + M[3][2]*x[2] + M[3][3];
      return Vec3f((M[0][0]*x[0] + M[0][1]*x[1] + M[0][2]*x[2] + M[0][3])/w,
                   (M[1][0]*x[0] + M[1][1]*x[1] + M[1][2]*x[2] + M[1][3])/w,
                   (M[2][0]*x[0] + M[2][1]*x[1] + M[2][2]*x[2] + M[2][3])/w);
   }

   Vec3f apply_to_direction(const Vec3f& d) const
   {
      return Vec3f(M[0][0]*d[0] + M[0][1]*d[1] + M[0][2]*d[2],
                   M[1][0]*d[0] + M[1][1]*d[1] + M[1][2]*d[2],
                   M[2][0]*d[0] + M[2][1]*d[1] + M[2][2]*d[2]);
   }
};

// There are also many operations, such as multiplication (composing a sequence
// of transformations), inversion, and transpositions; there are also primitive
// transformations for translation, rotation and scaling.

Transformation operator*(const Transformation& S, const Transformation& T);
Transformation operator*=(Transformation& S, const Transformation& T);
Transformation inverse(const Transformation& T);
Transformation transpose(const Transformation& T);
Transformation translate(const Vec3f& tx);
Transformation rotate_x(float degrees);
Transformation rotate_y(float degrees);
Transformation rotate_z(float degrees);
Transformation scale(float sx, float sy, float sz);

#endif
