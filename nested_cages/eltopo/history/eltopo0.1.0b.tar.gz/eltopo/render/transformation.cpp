#include "transformation.h"

Transformation operator*(const Transformation& S, const Transformation& T)
{
   // just matrix multiplication
   Transformation U; // U=S*T
   for(int i=0; i<4; ++i) for(int j=0; j<4; ++j){
      U.M[i][j]=0;
      for(int k=0; k<4; ++k) U.M[i][j]+=S.M[i][k]*T.M[k][j];
   }
   return U;
}

Transformation operator*=(Transformation& S, const Transformation& T)
{
   return S=S*T;
}

Transformation inverse(const Transformation& T)
{
   // This is somewhat scary looking code, implementing a robust matrix inversion
   // algorithm based on the Modified Gram-Schmidt process for QR factorization.
   // We actually instead factor T.M as R*Q, where R is upper triangular and Q is
   // orthogonal; if the transformation is a combination of rotations and translations,
   // this boils down to writing is as a single rotation followed by a single translation.
   // If the matrix is singular, we can fairly robustly detect this and provide a
   // plausible inverse.
   float Rinv[4][4]={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}}, Q[4][4], qrow[4];
   // get norm of M to later check if matrix is singular
   float Mnorm=0;
   for(int i=0; i<4; ++i) for(int j=0; j<4; ++j) Mnorm+=sqr(T.M[i][j]);
   Mnorm=std::sqrt(Mnorm);
   // do the RQ factorization with Modified Gram-Schmidt, storing inverse of R instead of R
   for(int i=3; i>=0; --i){
      for(int k=0; k<4; ++k) qrow[k]=T.M[i][k];
      for(int j=i+1; j<4; ++j){
         float rij=qrow[0]*Q[j][0]+qrow[1]*Q[j][1]+qrow[2]*Q[j][2]+qrow[3]*Q[j][3];
         for(int k=0; k<4; ++k){
            qrow[k]-=rij*Q[j][k];
            Rinv[i][k]-=rij*Rinv[j][k];
         }
      }
      float qnorm=std::sqrt(sqr(qrow[0])+sqr(qrow[1])+sqr(qrow[2])+sqr(qrow[3]));
      if(qnorm>1e-5*Mnorm){ // test for nonsingularity
         for(int k=0; k<4; ++k){
            Q[i][k]=qrow[k]/qnorm;
            Rinv[i][k]/=qnorm;
         }
      }
   }
   // multiply the transpose of Q by inverse of R to get the inverse of M
   Transformation inv;
   for(int i=0; i<4; ++i) for(int j=0; j<4; ++j){
      inv.M[i][j]=0;
      for(int k=0; k<4; ++k) inv.M[i][j]+=Q[k][i]*Rinv[k][j];
   }
   return inv;
}

Transformation transpose(const Transformation& T)
{
   Transformation S;
   for(int i=0; i<4; ++i) for(int j=0; j<4; ++j) S.M[i][j]=T.M[j][i];
   return S;
}

Transformation translate(const Vec3f& tx)
{
   Transformation T;
   T.M[0][3]=tx[0];
   T.M[1][3]=tx[1];
   T.M[2][3]=tx[2];
   return T;
}

Transformation rotate_x(float degrees)
{
   Transformation T;
   T.M[1][1]=(float)std::cos(degrees*M_PI/180);
   T.M[2][1]=(float)std::sin(degrees*M_PI/180);
   T.M[1][2]=-T.M[2][1];
   T.M[2][2]=T.M[1][1];
   return T;
}

Transformation rotate_y(float degrees)
{
   Transformation T;
   T.M[0][0]=(float)std::cos(degrees*M_PI/180);
   T.M[0][2]=(float)std::sin(degrees*M_PI/180);
   T.M[2][0]=-T.M[0][2];
   T.M[2][2]=T.M[0][0];
   return T;
}

Transformation rotate_z(float degrees)
{
   Transformation T;
   T.M[0][0]=(float)std::cos(degrees*M_PI/180);
   T.M[1][0]=(float)std::sin(degrees*M_PI/180);
   T.M[0][1]=-T.M[1][0];
   T.M[1][1]=T.M[0][0];
   return T;
}

Transformation scale(float sx, float sy, float sz)
{
   Transformation T;
   T.M[0][0]=sx;
   T.M[1][1]=sy;
   T.M[2][2]=sz;
   return T;
}

