#include <cfloat>
#include "camera.h"

void Camera::
render_image(Array2<Vec3f>& image) const
{
   // first invert the model-matrix transformation to speed up transforming rays from
   // camera space to world space.
   Transformation mvinv=inverse(modelview);
   // black out the image, resizing it to the desired dimensions
   image.assign(pixel_width, pixel_height, Vec3f(1,1,1));
   // loop over all pixels, tracing rays as we go
   for(int j=0; j<pixel_height; ++j){
      for(int i=0; i<pixel_width; ++i){
         Ray ray=generate_ray(mvinv, i+0.5f, j+0.5f);
         image(i,j)=raytracer.trace_ray(ray); // here's where we actually do raytracing for this pixel
      }
      // provide some feedback on the progress of the raytracer
      if(j%20==19) std::cout<<" scanline "<<j+1<<" of "<<pixel_height<<std::endl;
      else std::cout<<"."<<std::flush;
   }
}

Ray Camera::
generate_ray(const Transformation& modelview_inverse, float pixel_x, float pixel_y) const
{
   Vec3f cam_origin(left+(pixel_x/pixel_width)*(right-left),
                    bottom+(pixel_y/pixel_height)*(top-bottom),
                    -near);
   Vec3f cam_direction(cam_origin);
   Ray ray(modelview_inverse.apply_to_point(cam_origin),
           modelview_inverse.apply_to_direction(cam_direction));
   normalize(ray.direction);
   return ray;
}

void Camera::
render_image(Array2<Vec3f>& image, int supersampling) const
{
   // first invert the model-matrix transformation to speed up transforming rays from
   // camera space to world space.
   Transformation mvinv=inverse(modelview);
   // black out the image, resizing it to the desired dimensions
   image.assign(pixel_width, pixel_height, Vec3f(1,1,1));
   Array2f weight(pixel_width, pixel_height, 0.f);
   // loop over all pixels, tracing rays as we go
   unsigned int seed=0;
   for(int j=0; j<pixel_height; ++j){
      for(int i=0; i<pixel_width; ++i){
         for(int jj=0; jj<supersampling; ++jj) for(int ii=0; ii<supersampling; ++ii){
            //float subi=(ii+0.5)/supersampling, subj=(jj+0.5)/supersampling;
            float subi=(ii+randhashf(seed++))/supersampling;
            float subj=(jj+randhashf(seed++))/supersampling;
            Ray ray=generate_ray(mvinv, i+subi, j+subj);
            Vec3f colour=raytracer.trace_ray(ray); // here's where we actually do raytracing for this sample
            float u0, u1, u2, v0, v1, v2;
            quadratic_bspline_weights(subi, u0, u1, u2);
            quadratic_bspline_weights(subj, v0, v1, v2);
            if(i>0){
               if(j>0){ weight(i-1,j-1)+=u0*v0; image(i-1,j-1)+=(u0*v0)*colour; }
               weight(i-1,j)+=u0*v1; image(i-1,j)+=(u0*v1)*colour;
               if(j+1<pixel_height){ weight(i-1,j+1)+=u0*v2; image(i-1,j+1)+=(u0*v2)*colour; }
            }
            if(j>0){ weight(i,j-1)+=u1*v0; image(i,j-1)+=(u1*v0)*colour; }
            weight(i,j)+=u1*v1; image(i,j)+=(u1*v1)*colour;
            if(j+1<pixel_height){ weight(i,j+1)+=u1*v2; image(i,j+1)+=(u1*v2)*colour; }
            if(i+1<pixel_width){
               if(j>0){ weight(i+1,j-1)+=u2*v0; image(i+1,j-1)+=(u2*v0)*colour; }
               weight(i+1,j)+=u2*v1; image(i+1,j)+=(u2*v1)*colour;
               if(j+1<pixel_height){ weight(i+1,j+1)+=u2*v2; image(i+1,j+1)+=(u2*v2)*colour; }
            }
         }
      }
      // provide some feedback on the progress of the raytracer
      if(j%20==19) std::cout<<" scanline "<<j+1<<" of "<<pixel_height<<std::endl;
      else std::cout<<"."<<std::flush;
   }
   std::cout<<"normalizing..."<<std::flush;
   for(int j=0; j<pixel_height; ++j) for(int i=0; i<pixel_width; ++i)
      if(weight(i,j)) image(i,j)/=weight(i,j);
   std::cout<<" done."<<std::endl;
}

