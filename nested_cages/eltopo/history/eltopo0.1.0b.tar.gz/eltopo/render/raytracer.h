#ifndef RAYTRACER_H
#define RAYTRACER_H

// This is the heart of the ray-tracing code: the raytracer itself.
// It relies on being given a full description of the scene---basically
// a reference to the Lighting object for the scene, and a reference to
// the Shape object which encapsulates all geometry---and then lets
// you shoot rays to find colors with trace_ray().
//
// There are two extra parameters that control the algorithm:
// max_depth refers to how deep the recursion (due to reflective surfaces) can go,
// and epsilon is a small number used to combat rounding errors when calculating
// secondary rays (they are offset from the first intersection with the primary
// ray by epsilon, to avoid the surface itself registering as an intersection for
// shadows or reflections).

#include <cfloat>
#include "primitives.h"
#include "lighting.h"
#include "shapes.h"

struct RayTracer
{
   int max_depth;
   float epsilon;
   const Lighting& lighting;
   const Shape& shape;

   RayTracer(const Lighting& lighting_, const Shape& shape_)
      : max_depth(6),
        epsilon(1e-4f),
        lighting(lighting_),
        shape(shape_)
   {}

   // returns the RGB value found along the given ray
   Vec3f trace_ray(const Ray& ray) const
   {
      // hand off the work to the recursive function below, specifying 0 as the start
      // (tmin) parameter value of the ray, and FLT_MAX --- which is as close to infinite
      // as a finite float can be --- as the end of the ray (tmax).
      return trace_ray(ray, 0, FLT_MAX, max_depth);
   }

   protected:
   // This is the actual recursive function where the work is done: depth_left is how much deeper
   // the recursion is allowed to go.
   Vec3f trace_ray(const Ray& ray, float tmin, float tmax, int depth_left) const;
};

#endif
