#ifndef SHAPES_H
#define SHAPES_H

// This file defines all the actual geometry we can intersect rays against.
// The Shape class is a pure virtual base class for specific shapes, providing three virtual
// member functions:
// quick_intersect() checks if a ray hits the geometry without worrying
//   about getting the first hit, the surface normal etc. --- good for shadow rays
// intersect() finds the first intersection with a ray, if there is one, and returns the surface normal etc.
// bounding_box() returns a bounding box that contains all the geometry in the shape
//
// Sub-classes defined here are Plane, Sphere, TriangleMesh, and AggregateShape; the last isn't a shape itself,
// but a collection of other shapes organized in a bounding volume hierarchy. Ultimately all of the geometry
// in the scene has to be encapsulated in a single shape, which will probably then be an AggregateShape
// which can include lots of other specific shapes.

#include "primitives.h"
#include "material.h"
#include "bounding_box_tree.h"

// pure virtual base class for surface geometry (shapes) that can be raytraced
struct Shape
{
   virtual ~Shape(void) {}

   // check if there is any intersection in the range (tmin,tmax) - not necessarily finding the first
   virtual bool quick_intersect(const Ray& ray, float tmin, float tmax) const = 0;

   // find the first intersection in the range, returning it as t, and also return surface normal and material
   virtual bool intersect(const Ray& ray, float tmin, float tmax, float &t, Vec3f& surface_normal, Material& surface_material) const = 0;

   // return a bounding box - useful for acceleration structures
   virtual BoundingBox bounding_box(void) const = 0;
};

// a (nearly) infinite plane
struct Plane: public Shape
{
   Material material;
   Vec3f point, normal;
   float bound; // to make planes work with bounding boxes, we add a bound (distance from point)

   Plane(void) : material(), point(0.f,0.f,0.f), normal(0.f,1.f,0.f), bound(1e4f) {}

   Plane(const Vec3f& point_, const Vec3f& normal_, float bound_)
      : material(),
        point(point_),
        normal(normal_),
        bound(bound_)
   {}

   bool quick_intersect(const Ray& ray, float tmin, float tmax) const;
   bool intersect(const Ray& ray, float tmin, float tmax, float& t, Vec3f& surface_normal, Material& surface_material) const;
   BoundingBox bounding_box(void) const;
};

// a textured (nearly) infinite plane
struct CheckeredPlane: public Plane
{
   float step;

   CheckeredPlane(void) : step(1) {}

   CheckeredPlane(const Vec3f& point_, const Vec3f& normal_, float bound_, float step_=1)
      : Plane(point_, normal_, bound_), step(step_)
   {}

   bool intersect(const Ray& ray, float tmin, float tmax, float& t, Vec3f& surface_normal, Material& surface_material) const;
};

// a perfect sphere
struct Sphere: public Shape
{
   Material material;
   Vec3f centre;
   float radius;

   Sphere(void) : material(), centre(0,0,0), radius(1) {}

   Sphere(const Vec3f& centre_, float radius_) : material(), centre(centre_), radius(radius_)
   { assert(radius>=0); }

   bool quick_intersect(const Ray& ray, float tmin, float tmax) const;
   bool intersect(const Ray& ray, float tmin, float tmax, float& t, Vec3f& surface_normal, Material& surface_material) const;
   BoundingBox bounding_box(void) const;
};

// a mesh of triangles
struct TriangleMesh: public Shape
{
   Material material;
   float epsilon; // a quantity to account for rounding error in calculations
   std::vector<Vec3i> tri; // an array of vertex indices, three per triangle (wihch index into the vertex array x)
   std::vector<Vec3f> x; // an array of vertex positions
   std::vector<Vec3f> normal; // if this is empty, face normals are assumed; otherwise interpolate vertex normals are used
   BoundingBoxTree tree; // a bounding volume hierarchy to speed up intersection tests

   TriangleMesh(void) : material(), epsilon(1e-5f), tri(0), x(0), normal(0), tree() {}

   // Note: after loading in triangles etc. it's important to call this before using the mesh, as it
   // computes the bounding box and the rest of a tree to accelerate the intersection tests. The other
   // functions rely on this having been built (and being up-to-date).
   void build_tree(void);

   bool quick_intersect(const Ray& ray, float tmin, float tmax) const;
   bool intersect(const Ray& ray, float tmin, float tmax, float& t, Vec3f& surface_normal, Material& surface_material) const;
   BoundingBox bounding_box(void) const;

   protected:
   bool intersect_triangle(unsigned int f, const Ray& ray, float tmin, float tmax, float& t, float& alpha, float& beta, float& gamma) const;
};

// a collection of other shapes; these may even be other AggregateShapes!
struct AggregateShape: public Shape
{
   std::vector<const Shape*> subshape; // an array of pointers to shapes included in the aggregate
   BoundingBoxTree tree; // a bounding volume hierarchy to speed up intersection tests

   AggregateShape(void) : subshape(0), tree() {}

   // Note: after loading in shapes it's important to call this before use, as it
   // computes the bounding box and the rest of a tree to accelerate the intersection tests. The other
   // functions rely on this having been built (and being up-to-date).
   void build_tree(void);

   bool quick_intersect(const Ray& ray, float tmin, float tmax) const;
   bool intersect(const Ray& ray, float tmin, float tmax, float& t, Vec3f& surface_normal, Material& surface_material) const;
   BoundingBox bounding_box(void) const;
};

#endif
